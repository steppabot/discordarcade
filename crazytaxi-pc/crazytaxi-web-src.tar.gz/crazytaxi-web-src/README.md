# Crazy Taxi (Dreamcast) for the Token arcade: web build sources

The game page is built with the Dreamcast Port Kit (https://github.com/dmikey/dreamcast-port-kit,
GPL-2.0) on dcrecomp (https://github.com/sp00nznet/dcrecomp, GPL-2.0). This bundle holds the
changes made for the arcade build. No game code or disc data is included: you need your own disc.

- patches/dreamcast-port-kit-41861a5.patch: against the kit at commit 41861a5.
  English system language at boot (BIOS system info at 0x8C000068 and a synthesized
  US flash ROM), and POSIX defines for the native Linux build.
- patches/dcrecomp-3c60e6f.patch: against dcrecomp at 3c60e6f, after the kit applies its own
  patches; the local change is the retail flash partition table in src/hal/dc_bios.c.
- web/runtime-worker.js, web/runtime-bridge.js: the kit's browser files, changed to read the
  game disc from a packed image (disc.json + parts) cached in the browser instead of a server.
- web/index.html: the arcade page (controls, touch pad, fullscreen).
- tools/ct_compact.py: makes the packed disc image from a GDI dump of your own disc.

Build: port.py prepare/translate with the crazy-taxi-usa profile, then
`port.py build-browser --optimize`; copy the browser output next to web/*, then run
`python3 tools/ct_compact.py <disc.gdi> <out-dir>` and host the out-dir where DISC_R2 in web/index.html points (or next to the page).
