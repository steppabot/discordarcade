# Crazy Taxi (Dreamcast) for the Token arcade: web build sources

The game page is built with the Dreamcast Port Kit (https://github.com/dmikey/dreamcast-port-kit,
GPL-2.0) on dcrecomp (https://github.com/sp00nznet/dcrecomp, GPL-2.0). This bundle holds the
changes made for the arcade build. No game code or disc data is included: you need your own disc.

- patches/dreamcast-port-kit-41861a5.patch: against the kit at commit 41861a5.
  English system language at boot (BIOS system info at 0x8C000068 and a synthesized
  US flash ROM), and POSIX defines for the native Linux build.
- patches/dcrecomp-3c60e6f.patch: against dcrecomp at 3c60e6f, after the kit applies its own
  patches; local changes: the retail flash partition table in src/hal/dc_bios.c, and a direct-mapped
  cache in front of the indirect-call lookup that tools/static_recompile.py generates.
  The kit patch also adds the same cache to the tail-call lookup in control_flow.py, and
  fixes AICA key-on in runtime/aica_mixer.h (a slot starts only from key-off, as in MAME:
  finished one-shots were replayed on every other channel's key-on), and replaces the
  per-material draw loop with a batched renderer (runtime/atlas_gl.h, batch_gl.h, hooked in
  graphics.py): all textures in one texture array sampled in the shader, per-vertex material
  bits, CPU back-face culling; ~1300 draw calls per frame become ~10-40.
  Speed work in the kit patch:
  - regcache.py + runtime/port_regcache.h: every translated function is rewritten so the
    SH-4 registers live in C locals, with inline RAM and store-queue access and the
    interrupt/vblank poll at function entry and loop back-edges. runtime/regcache_verify.c
    (build with PORT_RC_VERIFY=1) runs the original and rewritten function from the same
    state and compares registers, memory writes and TA output.
  - fastpath.py + runtime/port_fastpath.h, port_callcache.h: inline memory fast paths and a
    hashed indirect-call cache in dispatch_table.c.
  - indexed.py: the TA keeps each strip vertex once and emits index triples; batch_gl.h draws
    with glDrawElements and transparency.h sorts index triples.
  - arm7fast.py: the sound CPU fetches instructions straight from sound RAM; scheduler.py
    reads the clock every 4th poll. Store-queue bursts into plain RAM are one memcpy (browser.py).
    arm7idle.py is an idle skip for the sound CPU that stays disabled.
- web/runtime-worker.js, web/runtime-bridge.js: the kit's browser files, changed to read the
  game disc from a packed image (disc.json + parts) cached in the browser instead of a server.
- web/index.html: the arcade page (controls, touch pad, fullscreen).
- tools/ct_compact.py: makes the packed disc image from a GDI dump of your own disc.

Build: port.py prepare/translate with the crazy-taxi-usa profile, then
`port.py build-browser --jspi` (Asyncify and JSPI bundles); `tools/mkpkg.sh <dir>` strips and
gzips both next to web/*, then run
`python3 tools/ct_compact.py <disc.gdi> <out-dir>` and host the out-dir where DISC_R2 in web/index.html points (or next to the page).
