#!/usr/bin/env python3
"""Pack the parts of the Crazy Taxi GD-ROM tracks the game reads into a few small files.

Usage: ct_compact.py <gdi> <out dir>
The 1.19 GB high-density track is mostly padding: the ISO9660 area at its start and the
files at its end (LBA 497599-549000) are all the game uses. The output keeps those sector
ranges as raw 2352-byte sectors, split into parts of 20 MB (GitHub's web-upload limit),
with disc.json saying where each range lives. The browser answers the runtime's
/disc/<track>?offset=&length= reads from these parts, with zeros everywhere else.
"""
import hashlib, json, os, sys

SECTOR = 2352
PART_MAX = 20 * 1024 * 1024 // SECTOR * SECTOR

def main():
    gdi, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    base = os.path.dirname(os.path.abspath(gdi))
    lines = [l.split() for l in open(gdi).read().split('\n')[1:] if l.strip()]
    data_tracks = [(int(l[1]), os.path.join(base, l[4])) for l in lines if l[2] == '4']   # (lba, file)
    # The runtime numbers its tracks in this order (source-lock.json): track 0 = the low-density data
    # track, track 1 = the high-density data track.
    plan = []
    lba0, f0 = data_tracks[0]
    plan.append((0, f0, 0, os.path.getsize(f0) // SECTOR))                     # all of it (1 MB)
    lba1, f1 = data_tracks[1]
    sectors1 = os.path.getsize(f1) // SECTOR
    plan.append((1, f1, 0, 256))                                                  # IP.BIN, ISO9660 descriptors and directories
    tail = 497500 - lba1
    plan.append((1, f1, tail, sectors1 - tail))                                   # every file on the disc
    regions, stream_at, part, part_bytes, parts = [], 0, None, 0, []
    digest = hashlib.sha256()
    def open_part():
        nonlocal part, part_bytes
        if part: part.close()
        name = f'disc-{len(parts)}.bin'
        parts.append({'name': name, 'bytes': 0})
        part = open(os.path.join(out, name), 'wb'); part_bytes = 0
    open_part()
    for track, path, first, count in plan:
        regions.append({'track': track, 'firstSector': first, 'sectors': count, 'at': stream_at})
        with open(path, 'rb') as src:
            src.seek(first * SECTOR)
            left = count * SECTOR
            while left:
                if part_bytes == PART_MAX: open_part()
                n = min(left, PART_MAX - part_bytes, 1 << 20)
                buf = src.read(n)
                part.write(buf); digest.update(buf)
                part_bytes += n; parts[-1]['bytes'] += n; left -= n; stream_at += n
    part.close()
    manifest = {'sectorBytes': SECTOR, 'regions': regions, 'parts': parts, 'bytes': stream_at, 'sha256': digest.hexdigest()}
    json.dump(manifest, open(os.path.join(out, 'disc.json'), 'w'), indent=1)
    print(json.dumps({k: manifest[k] for k in ('bytes', 'regions')}), len(parts), 'parts')

if __name__ == '__main__':
    main()
