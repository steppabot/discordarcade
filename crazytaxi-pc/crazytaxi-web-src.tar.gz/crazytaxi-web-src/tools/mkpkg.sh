#!/bin/bash
# mkpkg.sh <out-dir> [build-dir]: page folder with the build's Asyncify + JSPI bundles,
# stripped and gzip-compressed (the worker unpacks them), plus links to the page files.
set -e
O=$1; B=${2:-/home/claude/ctweb/project/.local/browser}
SCR=/tmp/claude-0/-home-claude/e8707835-e345-5cab-ac22-be56539f9902/scratchpad
OPT=/opt/ems/binaryen-version_121/bin/wasm-opt
rm -rf "$O"; mkdir -p "$O"
for f in /home/claude/discordarcade/crazytaxi-pc/*; do b=$(basename $f); case $b in game*|runtime-loader.js) ;; *) ln -s "$(readlink -f $f)" "$O/$b";; esac; done
aw=$(grep -o 'game-[0-9a-f]*\.wasm' $B/game.js | head -1); jw=$(grep -o 'game-[0-9a-f]*\.wasm' $B/game-jspi.js | head -1)
$OPT --strip-debug --strip-producers --all-features $B/$aw -o $SCR/a.wasm
$OPT --strip-debug --strip-producers --all-features $B/$jw -o $SCR/j.wasm
as=$(sha256sum $SCR/a.wasm | cut -c1-64); js=$(sha256sum $SCR/j.wasm | cut -c1-64)
gzip -9 -c $SCR/a.wasm > "$O/game-${as:0:16}.wasm.gz"; gzip -9 -c $SCR/j.wasm > "$O/game-jspi-${js:0:16}.wasm.gz"
cp $B/game.js $B/game-jspi.js "$O/"
cat > "$O/runtime-loader.js" <<EOL
/* Generated bundle identities; older browsers keep the Asyncify build. */
'use strict';
{
 const builds={"asyncify": {"loader": "game.js", "suspension": "asyncify", "wasmSHA256": "$as", "wasmFile": "game-${as:0:16}.wasm.gz"}, "jspi": {"loader": "game-jspi.js", "suspension": "jspi", "wasmSHA256": "$js", "wasmFile": "game-jspi-${js:0:16}.wasm.gz"}};
 const nativeStack=typeof WebAssembly.Suspending==='function'&&typeof WebAssembly.promising==='function';
 self.portSelectedBuild=nativeStack&&builds.jspi?builds.jspi:builds.asyncify;
 if(!self.portSelectedBuild)throw new Error('Missing browser build configuration. Rebuild this project.');
 Module.print('[RUNTIME] suspension='+self.portSelectedBuild.suspension+' wasm='+self.portSelectedBuild.wasmSHA256);
 importScripts(self.portSelectedBuild.loader+self.location.search);
}
EOL
ls -la "$O" | grep -v "^l"
