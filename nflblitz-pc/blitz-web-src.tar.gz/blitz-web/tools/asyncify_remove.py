#!/usr/bin/env python3
"""Rebuild src/asyncify_remove.txt: the GLideN64 functions Asyncify would instrument.

GLideN64 only runs from rv_frame (never on a game fiber), so none of its functions is
ever on the stack when a fiber switches; Asyncify still instruments every function that
makes an indirect (virtual) call. This links once with -sASYNCIFY_ADVISE=1, takes the
functions it reports, and keeps those defined only in GLideN64 objects (template code
shared with the runtime stays instrumented). Run from the build directory after
`build.py compile`.
"""
import os, re, subprocess, sys

here = os.path.dirname(os.path.abspath(__file__))
g = {}
exec(open(os.path.join(here, "..", "build.py")).read().split('if __name__ == "__main__":')[0], g)
G, SOURCES, obj_for, LINK, W = g["G"], g["SOURCES"], g["obj_for"], g["LINK"], g["W"]

def defined(obj):
    out = subprocess.run(["llvm-nm", "--defined-only", obj], capture_output=True, text=True).stdout
    return {p[2] for p in (l.split() for l in out.splitlines()) if len(p) >= 3 and p[1] in "TtWw"}

glide, other = set(), set()
for s in SOURCES:
    (glide if s.startswith(G + "/") else other).update(defined(obj_for(s)))
only = sorted(glide - other)
demangled = set(subprocess.run(["llvm-cxxfilt"], input="\n".join(only), capture_output=True, text=True).stdout.splitlines())

tmp = os.path.join(W, "build", "advise")
os.makedirs(tmp, exist_ok=True)
link = [a for a in LINK if not a.startswith("-sASYNCIFY_REMOVE=")]
p = subprocess.run(["em++"] + [obj_for(s) for s in SOURCES] + link + ["-sASYNCIFY_ADVISE=1", "-o", tmp + "/blitz.js"],
                   capture_output=True, text=True)
if p.returncode:
    sys.exit(p.stderr[-2000:])
names = set()
for line in (p.stdout + p.stderr).splitlines():
    m = re.match(r"\[asyncify\] (.*) can change the state", line)
    if m:
        names.add(re.sub(r"\\([0-9a-f]{2})", lambda m: chr(int(m.group(1), 16)), m.group(1)))
keep = sorted(n for n in names if n in demangled)
open(os.path.join(W, "src", "asyncify_remove.txt"), "w").write("\n".join(keep) + "\n")
print(f"{len(keep)} GLideN64 functions left out of Asyncify")
