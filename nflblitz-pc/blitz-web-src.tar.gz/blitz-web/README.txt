NFL Blitz for the web: build sources
====================================

This is the source for nflblitz-pc/blitz.js + blitz.wasm on the Token arcade. The game
is NFL Blitz (N64, USA) statically recompiled to WebAssembly; no emulator runs.
No ROM, game code or game data is included here.

It combines:
- N64Recomp and RSPRecomp, https://github.com/N64Recomp/N64Recomp. The game code is
  generated from your own ROM:
    1. splat (recomp/disasm/blitz.yaml) disassembles it; n64sym names libultra.
    2. recomp/tools/recomp_loop.py runs gen_symbols.py (symbols TOML from the splat
       output, with the renames, skips, sizes and extra entry points in recomp/syms/)
       and N64Recomp (recomp/blitz.toml) until no fixes remain.
    3. RSPRecomp recomp/rsp/blitz_audio.toml builds the audio microcode.
- The runtime of WCWnWoRevengeRecomp (GPL-3.0), https://github.com/jessetbh/WCWnWoRevengeRecomp
  (its N64ModernRuntime submodule: librecomp, ultramodern), with
  n64modernruntime-blitz.patch applied. The patch adds two opt-in build switches:
  libultra-valued thread states (Blitz's process scheduler reads OSThread.state to
  clean up finished processes) and a hardware-like osAiGetLength (never more than the
  DMA in flight; Blitz sizes each audio frame from it).
- GLideN64 (GPL-2.0-or-later), https://github.com/gonetz/GLideN64 at commit
  a04081ad6a966a9413bea63a55f502e0dc98bb18, with gliden64-web.patch applied.
- The files in src/: cooperative (single-thread) versions of ultramodern's threads,
  message queues, timers and events on emscripten fibers (coop_*.cpp), the PI, DMA,
  overlay and save code (web_pi.cpp, web_overlays.cpp), Blitz's pieces (web_blitz.cpp:
  osYieldThread, the Controller Pak kept in the 32 KB save buffer), the boot and
  per-frame loop (web_main.cpp) and the GLideN64 glue (web_gliden64.cpp).

Build with Emscripten 4.0.1: edit the paths at the top of build.py, then
  python3 build.py compile && python3 build.py link

Asyncify: game threads are emscripten fibers. GLideN64 only runs between them, so the
functions in src/asyncify_remove.txt (made by tools/asyncify_remove.py) are left out of
Asyncify's instrumentation, which keeps drawing fast, above all in Safari.

Shaders: src/rv_combiner_keys.inc lists the GLideN64 combiner keys Blitz uses, recorded
by playing it (test/boot.mjs with KEYSOUT=file). They are built at start-up.
