// Cooperative scheduling for the web build: every N64 game thread is an emscripten
// fiber, exactly one runs at a time (as in ultramodern), and when none can run the
// browser's frame loop gets control back. See coop_threads.cpp.
#pragma once

// From a game fiber: hand the rest of this browser frame back to the frame loop. The
// calling thread is resumed by the next coop_run_game().
void coop_yield_to_main();

// From the browser frame loop: run game fibers until they all block or one yields.
void coop_run_game();

// True while the game is between frames waiting for the frame loop.
bool coop_game_started();
