/* Force-included into NFL Blitz's recompiled code (build.py): functions the game calls
 * that N64Recomp leaves out of funcs.h because they are library functions it skips;
 * src/web_blitz.cpp provides them. */
#ifndef BLITZ_DECLS_H
#define BLITZ_DECLS_H
#include <stdint.h>
#include "recomp.h"
#ifdef __cplusplus
extern "C" {
#endif
void osYieldThread_recomp(uint8_t* rdram, recomp_context* ctx);
void osViGetCurrentLine_recomp(uint8_t* rdram, recomp_context* ctx);
void __osContRamRead_recomp(uint8_t* rdram, recomp_context* ctx);
void __osContRamWrite_recomp(uint8_t* rdram, recomp_context* ctx);
void __osSiGetAccess_recomp(uint8_t* rdram, recomp_context* ctx);
void __osSiRelAccess_recomp(uint8_t* rdram, recomp_context* ctx);
void func_8001DD90(uint8_t* rdram, recomp_context* ctx);  /* blitz.toml ignored: plain name */
#ifdef __cplusplus
}
#endif
#endif
