#include <emscripten.h>
// Web build of librecomp pi.cpp: cart ROM reads, PI DMA and the cart SRAM save. The
// save buffer lives in memory; the page persists it (web_save_* below) instead of a
// saving thread writing files. Mods, ROM-patch save folders and save backups are not
// part of the web build.
#include <cassert>
#include <cstring>
#include <vector>
#include <span>
#include "recomp.h"
#include "librecomp/addresses.hpp"
#include "librecomp/game.hpp"
#include "librecomp/overlays.hpp"
#include <ultramodern/ultra64.h>
#include <ultramodern/ultramodern.hpp>
#include "web.hpp"

static std::vector<uint8_t> rom;

bool recomp::is_rom_loaded() {
    return !rom.empty();
}

void recomp::set_rom_contents(std::vector<uint8_t>&& new_rom) {
    rom = std::move(new_rom);
}

std::span<const uint8_t> recomp::get_rom() {
    return rom;
}

constexpr uint32_t k1_to_phys(uint32_t addr) {
    return addr & 0x1FFFFFFF;
}

constexpr uint32_t phys_to_k1(uint32_t addr) {
    return addr | 0xA0000000;
}

extern "C" void __osPiGetAccess_recomp(uint8_t* rdram, recomp_context* ctx) {
}

extern "C" void __osPiRelAccess_recomp(uint8_t* rdram, recomp_context* ctx) {
}

extern "C" void osCartRomInit_recomp(uint8_t* rdram, recomp_context* ctx) {
    OSPiHandle* handle = TO_PTR(OSPiHandle, recomp::cart_handle);
    handle->type = 0; // cart
    handle->baseAddress = phys_to_k1(recomp::rom_base);
    handle->domain = 0;
    ctx->r2 = (gpr)recomp::cart_handle;
}

extern "C" void osDriveRomInit_recomp(uint8_t* rdram, recomp_context* ctx) {
    OSPiHandle* handle = TO_PTR(OSPiHandle, recomp::drive_handle);
    handle->type = 1; // bulk
    handle->baseAddress = phys_to_k1(recomp::drive_base);
    handle->domain = 0;
    ctx->r2 = (gpr)recomp::drive_handle;
}

extern "C" void osCreatePiManager_recomp(uint8_t* rdram, recomp_context* ctx) {
}

void recomp::do_rom_read(uint8_t* rdram, gpr ram_address, uint32_t physical_addr, size_t num_bytes) {
    size_t off = (size_t)physical_addr - (size_t)recomp::rom_base;
    if (physical_addr < recomp::rom_base || off + num_bytes > rom.size()) {
        fprintf(stderr, "[web][rom] refusing out-of-range read rom=0x%zX len=0x%zX\n", off, num_bytes);
        return;
    }
    const uint8_t* src = rom.data() + off;
    // rdram holds native 32-bit words (byte address ^ 3): aligned spans copy as
    // byte-swapped words, the rest byte by byte.
    size_t i = 0;
    if (((uint32_t)ram_address & 3) == 0 && (off & 3) == 0) {
        uint32_t* dst = (uint32_t*)(rdram + ((uint32_t)ram_address - 0x80000000u));
        for (; i + 4 <= num_bytes; i += 4) {
            uint32_t w;
            memcpy(&w, src + i, 4);
            *dst++ = __builtin_bswap32(w);
        }
    }
    for (; i < num_bytes; i++) {
        MEM_B(i, ram_address) = src[i];
    }
}

void recomp::do_rom_pio(uint8_t* rdram, gpr ram_address, uint32_t physical_addr) {
    const uint8_t* rom_addr = rom.data() + physical_addr - recomp::rom_base;
    MEM_B(0, ram_address) = rom_addr[0];
    MEM_B(1, ram_address) = rom_addr[1];
    MEM_B(2, ram_address) = rom_addr[2];
    MEM_B(3, ram_address) = rom_addr[3];
}

// ---- Save (cart SRAM, 32 KB) ---------------------------------------------------------
static std::vector<char> save_buffer;
static bool save_dirty = false;

static size_t get_save_size(recomp::SaveType save_type) {
    switch (save_type) {
        case recomp::SaveType::AllowAll:
        case recomp::SaveType::Flashram: return 0x20000;
        case recomp::SaveType::Sram: return 0x8000;
        case recomp::SaveType::Eep16k: return 0x800;
        case recomp::SaveType::Eep4k: return 0x200;
        case recomp::SaveType::None: return 0;
    }
    return 0;
}

void save_write_ptr(const void* in, uint32_t offset, uint32_t count) {
    if (offset + count > save_buffer.size()) return;
    memcpy(&save_buffer[offset], in, count);
    save_dirty = true;
}

void save_write(RDRAM_ARG PTR(void) rdram_address, uint32_t offset, uint32_t count) {
    if (offset + count > save_buffer.size()) return;
    for (gpr i = 0; i < count; i++) {
        save_buffer[offset + i] = MEM_B(i, rdram_address);
    }
    save_dirty = true;
}

void save_read(RDRAM_ARG PTR(void) rdram_address, uint32_t offset, uint32_t count) {
    if (offset + count > save_buffer.size()) return;
    for (gpr i = 0; i < count; i++) {
        MEM_B(i, rdram_address) = save_buffer[offset + i];
    }
}

void save_read_ptr(void* out, uint32_t offset, uint32_t count) {
    if (offset + count > save_buffer.size()) return;
    memcpy(out, save_buffer.data() + offset, count);
}

void save_clear(uint32_t start, uint32_t size, char value) {
    if (start + size > save_buffer.size()) return;
    std::fill_n(save_buffer.begin() + start, size, value);
    save_dirty = true;
}

void ultramodern::init_saving(RDRAM_ARG1) {
    if (save_buffer.empty()) {
        save_buffer.assign(get_save_size(recomp::get_save_type()), 0);
    }
}

void web_save_load(const uint8_t* data, uint32_t size) {
    if (save_buffer.empty()) {
        save_buffer.assign(get_save_size(recomp::get_save_type()), 0);
    }
    memcpy(save_buffer.data(), data, std::min<size_t>(size, save_buffer.size()));
}

bool web_save_dirty() {
    bool d = save_dirty;
    save_dirty = false;
    return d;
}

const uint8_t* web_save_data(uint32_t* size) {
    *size = (uint32_t)save_buffer.size();
    return (const uint8_t*)save_buffer.data();
}

void ultramodern::change_save_file(const std::u8string& subfolder, const std::u8string& name) {
}

void ultramodern::join_saving_thread() {
}

// ---- PI DMA --------------------------------------------------------------------------
extern "C" void web_dma_overlays(uint32_t rom, int32_t ram_addr, uint32_t size);

void do_dma(RDRAM_ARG PTR(OSMesgQueue) mq, gpr rdram_address, uint32_t physical_addr, uint32_t size, uint32_t direction) {
    static int dma_log = -1;
    if (dma_log < 0) dma_log = EM_ASM_INT({ return (typeof Module !== 'undefined' && Module.bzDmaLog) ? 1 : 0; });
    if (dma_log) fprintf(stderr, "[dma] dir=%u phys=0x%08X ram=0x%08X size=0x%X\n", direction, physical_addr, (uint32_t)rdram_address, size);
    if (direction == 0) {
        if (physical_addr >= recomp::rom_base) {
            recomp::do_rom_read(rdram, rdram_address, physical_addr, size);
            // A ROM DMA replaces any code mapped where it lands and maps the code
            // sections it brought in (Blitz swaps three overlays at 0x802AF750).
            web_dma_overlays(physical_addr - (uint32_t)recomp::rom_base, (int32_t)(uint32_t)rdram_address, size);
            ultramodern::enqueue_external_message(mq, 0, false, true);
        } else if (physical_addr >= recomp::sram_base) {
            save_read(rdram, rdram_address, physical_addr - recomp::sram_base, size);
            ultramodern::enqueue_external_message(mq, 0, false, true);
        } else {
            fprintf(stderr, "[web][pi] DMA read from unknown region 0x%08X\n", physical_addr);
        }
    } else {
        if (physical_addr >= recomp::rom_base) {
            fprintf(stderr, "[web][pi] ROM DMA write ignored\n");
        } else if (physical_addr >= recomp::sram_base) {
            save_write(rdram, rdram_address, physical_addr - recomp::sram_base, size);
            ultramodern::enqueue_external_message(mq, 0, false, true);
        } else {
            fprintf(stderr, "[web][pi] DMA write to unknown region 0x%08X\n", physical_addr);
        }
    }
}

extern "C" void osPiStartDma_recomp(RDRAM_ARG recomp_context* ctx) {
    uint32_t direction = ctx->r6;
    uint32_t devAddr = ctx->r7 | recomp::rom_base;
    gpr dramAddr = MEM_W(0x10, ctx->r29);
    uint32_t size = MEM_W(0x14, ctx->r29);
    PTR(OSMesgQueue) mq = MEM_W(0x18, ctx->r29);
    do_dma(PASS_RDRAM mq, dramAddr, k1_to_phys(devAddr), size, direction);
    ctx->r2 = 0;
}

extern "C" void osEPiStartDma_recomp(RDRAM_ARG recomp_context* ctx) {
    OSPiHandle* handle = TO_PTR(OSPiHandle, ctx->r4);
    OSIoMesg* mb = TO_PTR(OSIoMesg, ctx->r5);
    uint32_t direction = ctx->r6;
    uint32_t devAddr = handle->baseAddress | mb->devAddr;
    do_dma(PASS_RDRAM mb->hdr.retQueue, mb->dramAddr, k1_to_phys(devAddr), mb->size, direction);
    ctx->r2 = 0;
}

extern "C" void osEPiReadIo_recomp(RDRAM_ARG recomp_context* ctx) {
    OSPiHandle* handle = TO_PTR(OSPiHandle, ctx->r4);
    uint32_t devAddr = handle->baseAddress | ctx->r5;
    gpr dramAddr = ctx->r6;
    uint32_t physical_addr = k1_to_phys(devAddr);
    if (physical_addr > recomp::rom_base) {
        recomp::do_rom_pio(PASS_RDRAM dramAddr, physical_addr);
    }
    ctx->r2 = 0;
}

extern "C" void osPiGetStatus_recomp(RDRAM_ARG recomp_context* ctx) {
    ctx->r2 = 0;
}

extern "C" void osPiRawStartDma_recomp(RDRAM_ARG recomp_context* ctx) {
    fprintf(stderr, "[web][pi] osPiRawStartDma called (unsupported)\n");
}

extern "C" void osEPiRawStartDma_recomp(RDRAM_ARG recomp_context* ctx) {
    fprintf(stderr, "[web][pi] osEPiRawStartDma called (unsupported)\n");
}

// ---- File helpers referenced by si.cpp's separate pak image (off for Revenge) ----------
#include "librecomp/files.hpp"
#include "librecomp/save_backups.hpp"

std::filesystem::path ultramodern::get_save_file_path() {
    return "/save/revenge.bin";
}

std::ifstream recomp::open_input_file_with_backup(const std::filesystem::path& filepath, std::ios_base::openmode mode) {
    return std::ifstream{ filepath, mode };
}

std::ofstream recomp::open_output_file_with_backup(const std::filesystem::path& filepath, std::ios_base::openmode mode) {
    return std::ofstream{ filepath, mode };
}

bool recomp::finalize_output_file_with_backup(const std::filesystem::path& filepath) {
    return true;
}

bool recomp::save_backups::backup_save_file(const std::filesystem::path& save_file, BackupReason reason) {
    return true;
}
