// NFL Blitz runtime pieces the shared web runtime doesn't have:
//  - osYieldThread / osViGetCurrentLine, which Blitz's own code calls directly;
//  - a Controller Pak in port 1. Blitz's libultra pfs code runs recompiled (see
//    tools/gen_symbols.py KEEP_AS_GAME); this file provides the layer under it:
//    32-byte block reads/writes of a 32 KB pak image, pak status, SI access.
//    The image is the 32 KB save buffer of web_pi.cpp (SaveType::Sram), which
//    the page keeps in localStorage. A blank image is formatted on first use.
#include <cstdint>
#include <cstring>
#include <cmath>
#include <emscripten.h>
#include "ultramodern/ultra64.h"
#include "ultramodern/ultramodern.hpp"
#include "recomp.h"
#include "helpers.hpp"
#include "coop.hpp"

void swap_to_thread(RDRAM_ARG OSThread* to);   // scheduling.cpp
void dequeue_external_messages(RDRAM_ARG1);    // coop_mesgqueue.cpp
void save_read_ptr(void* out, uint32_t offset, uint32_t count);          // web_pi.cpp
void save_write_ptr(const void* in, uint32_t offset, uint32_t count);

// ---- Threads ---------------------------------------------------------------------
// osYieldThread: hand the CPU to a ready thread of equal or higher priority. With
// none ready, a loop calling this is waiting on an interrupt-driven event (VI, SP,
// AI, timers); in the cooperative runtime those arrive from the frame loop, so go
// back to it (at most every 2 ms) and resume on the next frame.
// Pending events are delivered first, as the interrupt would have on hardware: a
// process spinning on osYieldThread (Blitz waits for the music to stop this way after
// Start) otherwise starves the retrace messages its sound driver needs to get there.
extern "C" void osYieldThread_recomp(uint8_t* rdram, recomp_context* ctx) {
    dequeue_external_messages(PASS_RDRAM1);
    if (!ultramodern::thread_queue_empty(PASS_RDRAM ultramodern::running_queue)) {
        PTR(OSThread) next_ = ultramodern::thread_queue_peek(PASS_RDRAM ultramodern::running_queue);
        OSThread* next = TO_PTR(OSThread, next_);
        OSThread* self = TO_PTR(OSThread, ultramodern::this_thread());
        if (next->priority >= self->priority) {
            ultramodern::thread_queue_pop(PASS_RDRAM ultramodern::running_queue);
            swap_to_thread(PASS_RDRAM next);
            return;
        }
    }
    static double last_main = 0;
    double now = emscripten_get_now();
    if (now - last_main >= 2.0) {
        last_main = now;
        coop_yield_to_main();
    }
}

// osViGetCurrentLine: the scanline the VI is on, from the time within the 60 Hz field.
extern "C" void osViGetCurrentLine_recomp(uint8_t* rdram, recomp_context* ctx) {
    const double field_ms = 1000.0 / 60.0;
    double t = std::fmod(emscripten_get_now(), field_ms) / field_ms;
    _return<uint32_t>(ctx, (uint32_t)(t * 525.0));
}

// ---- Controller Pak --------------------------------------------------------------
enum { PAK_BLOCK = 32, PAK_BLOCKS = 0x400, PAK_SIZE = PAK_BLOCK * PAK_BLOCKS, PFS_ERR_NOPACK = 1 };

static void put16(uint8_t* p, uint16_t v) { p[0] = v >> 8; p[1] = v & 0xFF; }
static void put32(uint8_t* p, uint32_t v) { put16(p, v >> 16); put16(p + 2, v & 0xFFFF); }

// A freshly formatted pak (libultra layout): ID block at blocks 1/3/4/6, inode table
// (page 1) and its copy (page 2), empty directory (pages 3-4), data pages 5..127 free.
static void pak_format(uint8_t* img) {
    memset(img, 0, PAK_SIZE);
    uint8_t id[32] = {};
    put32(id + 0, 0xFFFFFFFF);          // repaired
    put32(id + 4, 0x426C747A);          // random
    put32(id + 8, 0x00000000); put32(id + 12, 0x00000001);   // serial
    put32(id + 16, 0x00000000); put32(id + 20, 0x00000002);
    put16(id + 24, 0x0001);             // deviceid: bit 0 = pak
    id[26] = 1;                         // banks
    id[27] = 0;                         // version
    uint16_t sum = 0, isum = 0;
    for (int i = 0; i < 28; i += 2) {
        uint16_t h = (uint16_t)(id[i] << 8 | id[i + 1]);
        sum += h; isum += (uint16_t)~h;
    }
    put16(id + 28, sum); put16(id + 30, isum);
    for (int block : {1, 3, 4, 6}) memcpy(img + block * PAK_BLOCK, id, sizeof id);
    uint8_t inode[256] = {};
    const int start_page = 1 + 2 + 2 * 1;   // 1 + directory pages + 2 * banks
    unsigned check = 0;
    for (int e = start_page; e < 128; e++) { inode[e * 2] = 0; inode[e * 2 + 1] = 3; check += 3; }  // PFS_PAGE_NOT_USED
    inode[1] = check & 0xFF;
    memcpy(img + 0x100, inode, sizeof inode);
    memcpy(img + 0x200, inode, sizeof inode);
}

static void pak_ensure_formatted() {
    static bool checked = false;
    if (checked) return;
    checked = true;
    static uint8_t img[PAK_SIZE];
    save_read_ptr(img, 0, PAK_SIZE);
    for (uint8_t b : img) if (b) return;    // the page loaded a saved pak
    pak_format(img);
    save_write_ptr(img, 0, PAK_SIZE);
}

// s32 __osContRamRead(OSMesgQueue* mq, int channel, u16 address, u8* buffer)
uint32_t web_pak_reads = 0, web_pak_writes = 0;   // rv_stat(6/7)

extern "C" void __osContRamRead_recomp(uint8_t* rdram, recomp_context* ctx) {
    int channel = (int)ctx->r5;
    web_pak_reads++;
    uint32_t block = (uint32_t)ctx->r6 & 0xFFFF;
    gpr buffer = ctx->r7;
    if (channel != 0) { _return<int32_t>(ctx, PFS_ERR_NOPACK); return; }
    pak_ensure_formatted();
    uint8_t data[PAK_BLOCK] = {};
    if (block < PAK_BLOCKS) save_read_ptr(data, block * PAK_BLOCK, PAK_BLOCK);   // bank select etc. read 0
    for (int i = 0; i < PAK_BLOCK; i++) MEM_B(i, buffer) = data[i];
    _return<int32_t>(ctx, 0);
}

// s32 __osContRamWrite(OSMesgQueue* mq, int channel, u16 address, u8* buffer, int force)
extern "C" void __osContRamWrite_recomp(uint8_t* rdram, recomp_context* ctx) {
    int channel = (int)ctx->r5;
    web_pak_writes++;
    uint32_t block = (uint32_t)ctx->r6 & 0xFFFF;
    gpr buffer = ctx->r7;
    if (channel != 0) { _return<int32_t>(ctx, PFS_ERR_NOPACK); return; }
    pak_ensure_formatted();
    if (block < PAK_BLOCKS) {                       // writes past 0x8000 (bank select) ignored
        uint8_t data[PAK_BLOCK];
        for (int i = 0; i < PAK_BLOCK; i++) data[i] = (uint8_t)MEM_B(i, buffer);
        save_write_ptr(data, block * PAK_BLOCK, PAK_BLOCK);
    }
    _return<int32_t>(ctx, 0);
}

// s32 __osPfsGetStatus(OSMesgQueue* mq, int channel): a pak sits in port 1 only.
// (Named in blitz.toml's ignored list, so the game calls it by its plain name.)
extern "C" void func_8001DD90(uint8_t* rdram, recomp_context* ctx) {
    _return<int32_t>(ctx, (int)ctx->r5 == 0 ? 0 : PFS_ERR_NOPACK);
}

// SI bus access is uncontended here.
extern "C" void __osSiGetAccess_recomp(uint8_t* rdram, recomp_context* ctx) {}
extern "C" void __osSiRelAccess_recomp(uint8_t* rdram, recomp_context* ctx) {}
