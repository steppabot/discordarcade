// NFL Blitz for the browser (runtime from the WCW/nWo Revenge web port): boot, the per-frame loop, and the page's hooks for
// audio, input and saves. The game's threads are emscripten fibers (coop_threads.cpp);
// the page calls rv_frame() once per animation frame.
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include <emscripten.h>
#include <emscripten/html5.h>

#include "recomp.h"
#include "librecomp/addresses.hpp"
#include "librecomp/game.hpp"
#include "librecomp/overlays.hpp"
#include "librecomp/rsp.hpp"
#include "ultramodern/ultramodern.hpp"
#include "ultramodern/ultra64.h"
#include "ultramodern/input.hpp"
#include "ultramodern/error_handling.hpp"
#include "ultramodern/threads.hpp"
#include "ultramodern/renderer_context.hpp"
#include "web.hpp"

#include "recomp_overlays.inl"

extern "C" void recomp_entrypoint(uint8_t* rdram, recomp_context* ctx);
extern RspUcodeFunc blitz_audio_ucode;
extern "C" void load_overlays(uint32_t rom, int32_t ram_addr, uint32_t size);

// ---- Pieces of librecomp recomp.cpp the game needs ------------------------------------
static bool game_started = false;
std::atomic_bool exited = false;

bool ultramodern::is_game_started() {
    return game_started;
}

void ultramodern::quit() {
    exited.store(true);
}

// Blitz saves to the Controller Pak; its 32 KB image lives in the 32 KB SRAM-sized save
// buffer (web_blitz.cpp), which the page already persists.
recomp::SaveType recomp::get_save_type() { return recomp::SaveType::Sram; }
bool recomp::eeprom_allowed() { return false; }
bool recomp::sram_allowed() { return true; }
bool recomp::flashram_allowed() { return false; }

void run_thread_function(uint8_t* rdram, uint64_t addr, uint64_t sp, uint64_t arg) {
    recomp_context ctx{};
    ctx.r29 = sp;
    ctx.r4 = arg;
    ctx.mips3_float_mode = 0;
    ctx.f_odd = &ctx.f0.u32h;
    recomp_func_t* func = get_function(addr);
    func(rdram, &ctx);
}

extern "C" void switch_error(const char* func, uint32_t vram, uint32_t jtbl) {
    fprintf(stderr, "[web] switch error in %s at 0x%08X (jump table 0x%08X)\n", func, vram, jtbl);
    emscripten_force_exit(1);
}

extern "C" void do_break(uint32_t vram) {
    fprintf(stderr, "[web] break at 0x%08X\n", vram);
    // Heap state at a break (the preprocessor splits EM_ASM's argument at bare commas,
    // so the JS sits inside a function call).
    EM_ASM({ (function () {
      if (!Module._rv_rdram) return;
      const base = Module._rv_rdram();
      const R = function (a) { return HEAPU32[(base + (a - 0x80000000)) >>> 2] >>> 0; };
      const h = function (v) { return (v >>> 0).toString(16); };
      const hp = R(0x80052458);
      console.error("[web] heap desc @" + h(hp) + ": " + [0, 1, 2, 3, 4, 5, 6, 7].map(function (k) { return h(R(hp + 4 * k)); }).join(" "));
      let blk = R(hp + 4), n = 0, maxFree = 0;
      const sums = {}, used = [];
      while (blk >= 0x80000000 && blk < 0x80800000 && n < 5000) {
        if (n < 4) console.error("  block @" + h(blk) + ": " + [0, 1, 2, 3, 4, 5, 6, 7].map(function (k) { return h(R(blk + 4 * k)); }).join(" "));
        const f = R(blk + 0x10), size = f & 0x0FFFFFFF, fl = f >>> 28;
        sums[fl] = (sums[fl] || 0) + size;
        if (fl === 0 && size > maxFree) maxFree = size;
        if (fl !== 0) used.push(size);
        const next = R(blk + 8);
        n++; if (!next || next === blk) break; blk = next;
      }
      used.sort(function (x, y) { return y - x; });
      console.error("[web] heap blocks walked: " + n + " bytes by flag " + JSON.stringify(sums) + " largest free " + h(maxFree) + " largest used " + used.slice(0, 12).map(h).join(" "));
    })(); });
    EM_ASM({ console.error("[web] call chain at break:\n" + new Error().stack.split("\n").filter(l => /func_|osC|osS|osR/.test(l)).slice(0, 24).join("\n")); });
    emscripten_force_exit(1);
}

// RT64 hooks in the recompiled code: the web renderer has no raytracing or widescreen.



// ---- RSP microcode ---------------------------------------------------------------------
static RspExitReason null_ucode(uint8_t* rdram, uint32_t ucode_addr) {
    return RspExitReason::Broke;
}

static RspUcodeFunc* get_rsp_microcode(const OSTask* task) {
    if (task->t.type == M_AUDTASK) {
        return &blitz_audio_ucode;
    }
    fprintf(stderr, "[web][rsp] unknown task type %u\n", (unsigned)task->t.type);
    return &null_ucode;
}

// ---- Audio: the page's AudioWorklet queue (see rv-audio.js) ------------------------------
static void queue_samples(int16_t* audio_data, size_t sample_count) {
    // Interleaved stereo with L/R swapped by rdram's halfword order; swap back.
    static std::vector<int16_t> buf;
    buf.resize(sample_count);
    for (size_t i = 0; i + 1 < sample_count; i += 2) {
        buf[i + 0] = audio_data[i + 1];
        buf[i + 1] = audio_data[i + 0];
    }
    EM_ASM({ Module.rvAudioPush(HEAP16.subarray($0 >> 1, ($0 >> 1) + $1)); }, buf.data(), (int)sample_count);
}

static size_t get_frames_remaining() {
    return (size_t)EM_ASM_INT({ return Module.rvAudioQueued(); });
}

static void set_frequency(uint32_t freq) {
    EM_ASM({ Module.rvAudioInit($0); }, freq);
}

// ---- Input: four pads set by the page --------------------------------------------------
struct WebPad { uint16_t buttons; float x, y; };
static WebPad pads[4];

// An N64 controller (0-3): button bits, stick -80..80 with up positive (as the
// GoldenEye page and the arcade's group code send it).
extern "C" EMSCRIPTEN_KEEPALIVE void rv_set_pad(int idx, int buttons, int x, int y) {
    if (idx < 0 || idx >= 4) return;
    pads[idx].buttons = (uint16_t)buttons;
    pads[idx].x = std::fmax(-1.0f, std::fmin(1.0f, x / 80.0f));
    pads[idx].y = std::fmax(-1.0f, std::fmin(1.0f, y / 80.0f));
}

static void poll_input() {
}

static bool get_input(int controller_num, uint16_t* buttons, float* x, float* y) {
    if (controller_num < 0 || controller_num >= 4) return false;
    *buttons = pads[controller_num].buttons;
    *x = pads[controller_num].x;
    *y = pads[controller_num].y;
    return true;
}

static void set_rumble(int controller_num, bool rumble) {
}

static ultramodern::input::connected_device_info_t get_connected_device_info(int controller_num) {
    // Every port has a pad (unused players read as idle), as in the PC version; port 1
    // carries the emulated Rumble Pak.
    return { .connected_device = ultramodern::input::Device::Controller,
             .connected_pak = controller_num == 0 ? ultramodern::input::Pak::RumblePak : ultramodern::input::Pak::None };
}

// ---- Renderer --------------------------------------------------------------------------
std::unique_ptr<ultramodern::renderer::RendererContext> web_create_renderer(uint8_t* rdram, ultramodern::renderer::WindowHandle window_handle, bool developer_mode);

static void message_box(const char* msg) {
    fprintf(stderr, "[web] %s\n", msg);
    EM_ASM({ if (Module.rvMessage) Module.rvMessage(UTF8ToString($0)); }, msg);
}

// ---- Boot ------------------------------------------------------------------------------
static uint8_t* rdram = nullptr;
// rdram covers the 8 MB the game sees plus librecomp's PI handles (0x80800000) and patch area.
static constexpr size_t RDRAM_BYTES = 16u << 20;

static bool boot() {
    FILE* f = fopen("/rom/blitz.z64", "rb");
    if (!f) {
        message_box("The ROM is missing.");
        return false;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    std::vector<uint8_t> data((size_t)size);
    size_t got = fread(data.data(), 1, data.size(), f);
    fclose(f);
    remove("/rom/blitz.z64"); // the game keeps its own copy
    if (got != data.size()) {
        message_box("Could not read the ROM.");
        return false;
    }
    recomp::set_rom_contents(std::move(data));

    static const recomp::rsp::callbacks_t rsp_callbacks{ .get_rsp_microcode = get_rsp_microcode };
    recomp::rsp::set_callbacks(rsp_callbacks);
    static const ultramodern::rsp::callbacks_t ultramodern_rsp_callbacks{
        .init = recomp::rsp::constants_init,
        .run_task = recomp::rsp::run_task,
    };
    ultramodern::renderer::callbacks_t renderer_callbacks{ .create_render_context = web_create_renderer };
    ultramodern::audio_callbacks_t audio_callbacks{ .queue_samples = queue_samples, .get_frames_remaining = get_frames_remaining, .set_frequency = set_frequency };
    ultramodern::input::callbacks_t input_callbacks{
        .poll_input = poll_input,
        .get_input = get_input,
        .set_rumble = set_rumble,
        .get_connected_device_info = get_connected_device_info,
    };
    ultramodern::gfx_callbacks_t gfx_callbacks{};
    ultramodern::events::callbacks_t events_callbacks{};
    ultramodern::error_handling::callbacks_t error_callbacks{ .message_box = message_box };
    ultramodern::threads::callbacks_t threads_callbacks{ .get_game_thread_name = [](const OSThread*) -> std::string { return "game"; } };
    ultramodern::set_callbacks(ultramodern_rsp_callbacks, renderer_callbacks, audio_callbacks, input_callbacks,
        gfx_callbacks, events_callbacks, error_callbacks, threads_callbacks);

    recomp::overlays::overlay_section_table_data_t sections{
        .code_sections = section_table,
        .num_code_sections = ARRLEN(section_table),
        .total_num_sections = num_sections,
    };
    recomp::overlays::overlays_by_index_t overlays{
        .table = overlay_sections_by_index,
        .len = ARRLEN(overlay_sections_by_index),
    };
    recomp::overlays::register_overlays(sections, overlays);

    rdram = (uint8_t*)aligned_alloc(64, RDRAM_BYTES);
    memset(rdram, 0, RDRAM_BYTES);

    ultramodern::renderer::WindowHandle window{};
    ultramodern::preinit(rdram, window);

    // librecomp init(): boot overlays, the IPL3's 1 MB copy, and the IPL3 globals.
    gpr entrypoint = (gpr)(int32_t)0x80000400;
    recomp::overlays::init_overlays();
    load_overlays(0x1000, (int32_t)entrypoint, 1024 * 1024);
    recomp::do_rom_read(rdram, entrypoint, 0x10001000, 0x100000);
    MEM_W(0x300, (gpr)(int32_t)0x80000000) = 1;           // osTvType: NTSC
    MEM_W(0x308, (gpr)(int32_t)0x80000000) = 0xB0000000u; // osRomBase
    MEM_W(0x30C, (gpr)(int32_t)0x80000000) = 0;           // osResetType: cold
    MEM_W(0x318, (gpr)(int32_t)0x80000000) = 8 * 1024 * 1024; // osMemSize

    ultramodern::init_saving(rdram);
    EM_ASM({ if (Module.rvLoadSave) Module.rvLoadSave(); });

    game_started = true;
    // The boot code creates and starts the main thread, then returns; the frame loop
    // runs that thread from the next rv_frame().
    recomp_context ctx{};
    ctx.f_odd = &ctx.f0.u32h;
    ctx.mips3_float_mode = 0;
    recomp_entrypoint(rdram, &ctx);
    return true;
}

// ---- Frame loop ------------------------------------------------------------------------
static double next_vi_ms = 0;
static constexpr double VI_MS = 1000.0 / 60.0;
static bool booted = false;

static double t_game = 0, t_gfx = 0, t_present = 0;

static void run_until_idle(double deadline) {
    for (int i = 0; i < 16; i++) {
        double a = emscripten_get_now();
        coop_run_game();
        double b = emscripten_get_now();
        bool drew = web_process_gfx();
        double c = emscripten_get_now();
        t_game += b - a;
        t_gfx += c - b;
        if (!drew || c > deadline) {
            break;
        }
    }
}

// One browser animation frame. Each retrace that fell due is delivered on its own and the
// game runs (and its display lists render) before the next one, as on hardware, so a
// game waiting on single retraces never sees them merged. Up to 4 per frame; after a
// stall of more than 8 (a hidden tab, a long load) the cadence restarts.
extern "C" EMSCRIPTEN_KEEPALIVE void rv_frame() {
    if (!booted) return;
    double now = emscripten_get_now();
    double deadline = now + 50.0;
    if (next_vi_ms == 0) next_vi_ms = now;
    if (next_vi_ms + 8 * VI_MS < now) next_vi_ms = now;
    int vi = 0;
    while (now >= next_vi_ms && vi < 4) {
        next_vi_ms += VI_MS;
        web_vi_tick();
        coop_service_timers();
        run_until_idle(deadline);
        vi++;
        if (emscripten_get_now() > deadline) break;
    }
    if (vi == 0) {
        coop_service_timers();
        run_until_idle(deadline);
    }
    double p0 = emscripten_get_now();
    web_present();
    t_present += emscripten_get_now() - p0;
}

// Page hooks for saves: the page reads the buffer when rv_save_dirty() says it changed.
extern "C" EMSCRIPTEN_KEEPALIVE int rv_save_dirty() { return web_save_dirty() ? 1 : 0; }
extern "C" EMSCRIPTEN_KEEPALIVE const uint8_t* rv_save_ptr() { uint32_t n; return web_save_data(&n); }
extern "C" EMSCRIPTEN_KEEPALIVE int rv_save_size() { uint32_t n; web_save_data(&n); return (int)n; }
extern "C" EMSCRIPTEN_KEEPALIVE void rv_save_load(const uint8_t* data, int size) { web_save_load(data, (uint32_t)size); }

extern uint32_t web_pak_reads, web_pak_writes;   // web_blitz.cpp
extern "C" double coop_thread_stat(int which);    // coop_threads.cpp

extern "C" EMSCRIPTEN_KEEPALIVE double rv_stat(int which) {
    switch (which) {
        case 0: return (double)web_total_vis;
        case 1: return (double)web_gfx_tasks;
        case 2: return (double)web_audio_tasks;
        case 3: return t_game;
        case 4: return t_gfx;
        case 5: return t_present;
        case 6: return (double)web_pak_reads;
        case 7: return (double)web_pak_writes;
        case 8: return coop_thread_stat(0);    // live game threads
        case 9: return coop_thread_stat(1);    // thread stacks allocated
        case 10: return coop_thread_stat(2);   // thread stacks reused
    }
    return 0;
}

extern "C" EMSCRIPTEN_KEEPALIVE uint8_t* rv_rdram() { return rdram; }

int main(int argc, char** argv) {
    booted = boot();
    if (booted) {
        EM_ASM({ if (Module.rvStarted) Module.rvStarted(); });
    }
    return 0;
}
