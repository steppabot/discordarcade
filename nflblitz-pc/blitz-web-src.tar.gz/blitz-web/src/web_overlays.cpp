#include <algorithm>
// Per-thread / per-overlay trace lines: build with -DRV_TRACE_LOG to see them (Blitz
// starts and ends game processes many times a second, so they are off by default).
#ifdef RV_TRACE_LOG
#define RV_TRACE(...) fprintf(__VA_ARGS__)
#else
#define RV_TRACE(...) ((void)0)
#endif
#include <cassert>
#include <cstdio>
#include <cstring>
#include <unordered_map>
#include <vector>

#include "ultramodern/ultramodern.hpp"

#include "recomp.h"
#include "recompiler/context.h"
#include "overlays.hpp"
#include "sections.h"

static recomp::overlays::overlay_section_table_data_t sections_info {};
static recomp::overlays::overlays_by_index_t overlays_info {};

static SectionTableEntry* patch_code_sections = nullptr;
size_t num_patch_code_sections = 0;
static std::vector<char> patch_data;

struct LoadedSection {
    int32_t loaded_ram_addr;
    size_t section_table_index;

    LoadedSection(int32_t loaded_ram_addr_, size_t section_table_index_) {
        loaded_ram_addr = loaded_ram_addr_;
        section_table_index = section_table_index_;
    }

    bool operator<(const LoadedSection& rhs) {
        return loaded_ram_addr < rhs.loaded_ram_addr;
    }
};

static std::unordered_map<uint32_t, uint16_t> code_sections_by_rom{};
static std::unordered_map<uint32_t, uint16_t> patch_code_sections_by_rom{};
static std::vector<LoadedSection> loaded_sections{};
static std::unordered_map<int32_t, recomp_func_t*> func_map{};
static std::unordered_map<std::string, recomp_func_t*> base_exports{};
static std::unordered_map<std::string, recomp_func_ext_t*> ext_base_exports{};
static std::unordered_map<std::string, size_t> base_events;
static std::unordered_map<uint32_t, recomp_func_t*> manual_patch_symbols_by_vram;

extern "C" {
int32_t* section_addresses = nullptr;
}

void recomp::overlays::register_overlays(const overlay_section_table_data_t& sections, const overlays_by_index_t& overlays) {
    sections_info = sections;
    overlays_info = overlays;
}

void recomp::overlays::register_patches(const char* patch, std::size_t size, SectionTableEntry* sections, size_t num_sections) {
    patch_code_sections = sections;
    num_patch_code_sections = num_sections;

    patch_data.resize(size);
    std::memcpy(patch_data.data(), patch, size);

    patch_code_sections_by_rom.reserve(num_patch_code_sections);
    for (size_t i = 0; i < num_patch_code_sections; i++) {
        patch_code_sections_by_rom.emplace(patch_code_sections[i].rom_addr, i);
    }
}

void recomp::overlays::register_base_export(const std::string& name, recomp_func_t* func) {
    base_exports.emplace(name, func);
}

void recomp::overlays::register_ext_base_export(const std::string& name, recomp_func_ext_t* func) {
    ext_base_exports.emplace(name, func);
}

void recomp::overlays::register_base_exports(const FunctionExport* export_list) {
    std::unordered_map<uint32_t, recomp_func_t*> patch_func_vram_map{};

    // Iterate over all patch functions to set up a mapping of their vram address.
    for (size_t patch_section_index = 0; patch_section_index < num_patch_code_sections; patch_section_index++) {
        const SectionTableEntry* cur_section = &patch_code_sections[patch_section_index];

        for (size_t func_index = 0; func_index < cur_section->num_funcs; func_index++) {
            const FuncEntry* cur_func = &cur_section->funcs[func_index];
            patch_func_vram_map.emplace(cur_section->ram_addr + cur_func->offset, cur_func->func);
        }
    }

    // Iterate over exports, using the vram mapping to create a name mapping.
    for (const FunctionExport* cur_export = &export_list[0]; cur_export->name != nullptr; cur_export++) {
        auto it = patch_func_vram_map.find(cur_export->ram_addr);
        if (it == patch_func_vram_map.end()) {
            assert(false && "Failed to find exported function in patch function sections!");
        }
        base_exports.emplace(cur_export->name, it->second);
    }
}

recomp_func_t* recomp::overlays::get_base_export(const std::string& export_name) {
    auto it = base_exports.find(export_name);
    if (it == base_exports.end()) {
        return nullptr;
    }
    return it->second;
}

recomp_func_ext_t* recomp::overlays::get_ext_base_export(const std::string& export_name) {
    auto it = ext_base_exports.find(export_name);
    if (it == ext_base_exports.end()) {
        return nullptr;
    }
    return it->second;
}

void recomp::overlays::register_base_events(char const* const* event_names) {
    for (size_t event_index = 0; event_names[event_index] != nullptr; event_index++) {
        base_events.emplace(event_names[event_index], event_index);
    }
}

size_t recomp::overlays::get_base_event_index(const std::string& event_name) {
    auto it = base_events.find(event_name);
    if (it == base_events.end()) {
        return (size_t)-1;
    }
    return it->second;
}

size_t recomp::overlays::num_base_events() {
    return base_events.size();
}

const std::unordered_map<uint32_t, uint16_t>& recomp::overlays::get_vrom_to_section_map() {
    return code_sections_by_rom;
}

uint32_t recomp::overlays::get_section_ram_addr(uint16_t code_section_index) {
    return sections_info.code_sections[code_section_index].ram_addr;
}

std::span<const RelocEntry> recomp::overlays::get_section_relocs(uint16_t code_section_index) {
    if (code_section_index < sections_info.num_code_sections) {
        const auto& section = sections_info.code_sections[code_section_index];
        return std::span{ section.relocs, section.num_relocs };
    }
    assert(false);
    return {};
}

size_t recomp::overlays::num_code_sections() {
    return sections_info.num_code_sections;
}

const SectionTableEntry& recomp::overlays::get_code_section(uint16_t code_section_index) {
    assert(code_section_index < sections_info.num_code_sections);
    return sections_info.code_sections[code_section_index];
}

void recomp::overlays::add_loaded_function(int32_t ram, recomp_func_t* func) {
    func_map[ram] = func;
}

void load_overlay(size_t section_table_index, int32_t ram) {
    const SectionTableEntry& section = sections_info.code_sections[section_table_index];

    for (size_t function_index = 0; function_index < section.num_funcs; function_index++) {
        const FuncEntry& func = section.funcs[function_index];
        func_map[ram + func.offset] = func.func;
    }

    loaded_sections.emplace_back(ram, section_table_index);
    section_addresses[section.index] = ram;
}

static void load_special_overlay(const SectionTableEntry& section, int32_t ram) {
    for (size_t function_index = 0; function_index < section.num_funcs; function_index++) {
        const FuncEntry& func = section.funcs[function_index];
        func_map[ram + func.offset] = func.func;
    }
}

static void load_patch_functions() {
    if (patch_code_sections == nullptr) {
        debug_printf("[Patch] No patch section was registered\n");
        return;
    }
    for (size_t i = 0; i < num_patch_code_sections; i++) {
        load_special_overlay(patch_code_sections[i], patch_code_sections[i].ram_addr);
    }
}

void recomp::overlays::read_patch_data(uint8_t* rdram, gpr patch_data_address) {
    for (size_t i = 0; i < patch_data.size(); i++) {
        MEM_B(i, patch_data_address) = patch_data[i];
    }
}

extern "C" void load_overlays(uint32_t rom, int32_t ram_addr, uint32_t size) {
    // Search for the first section that's included in the loaded rom range
    // Sections were sorted by `init_overlays` so we can use the bounds functions
    auto lower = std::lower_bound(&sections_info.code_sections[0], &sections_info.code_sections[sections_info.num_code_sections], rom,
        [](const SectionTableEntry& entry, uint32_t addr) {
            return entry.rom_addr < addr;
        }
    );
    auto upper = std::upper_bound(&sections_info.code_sections[0], &sections_info.code_sections[sections_info.num_code_sections], (uint32_t)(rom + size),
        [](uint32_t addr, const SectionTableEntry& entry) {
            return addr < entry.size + entry.rom_addr;
        }
    );
    // Load the overlays that were found
    for (auto it = lower; it != upper; ++it) {
        int32_t load_addr = it->rom_addr - rom + ram_addr;
        // [wcw fix] Only map sections landing at their registered ram address. Revenge stores
        // its two swap-overlays right after the fixed image (rom 0x3C770/0x834A0), INSIDE the
        // boot DMA's 1MB window — the boot-time load_overlays(0x1000, entrypoint, 1MB) call in
        // recomp.cpp would otherwise register them at bogus contiguous addresses (e.g. ovl_b at
        // 0x800828A0), which later collides with the real swap-in at 0x80090000 ("Cannot
        // partially unload section"). Every legitimate caller in this stack (boot fixed-segment
        // map, the pi.cpp overlay-swap hook, WT's layout) loads sections at their registered
        // address, so this filter is a no-op for them.
        if (load_addr != it->ram_addr) {
            continue;
        }
        load_overlay(std::distance(&sections_info.code_sections[0], it), load_addr);
    }
}

extern "C" void unload_overlay_by_id(uint32_t id) {
    uint32_t section_table_index = overlays_info.table[id];
    const SectionTableEntry& section = sections_info.code_sections[section_table_index];

    auto find_it = std::find_if(loaded_sections.begin(), loaded_sections.end(), [section_table_index](const LoadedSection& s) { return s.section_table_index == section_table_index; });

    if (find_it != loaded_sections.end()) {
        // Determine where each function was loaded to and remove that entry from the function map
        for (size_t func_index = 0; func_index < section.num_funcs; func_index++) {
            const auto& func = section.funcs[func_index];
            uint32_t func_address = func.offset + find_it->loaded_ram_addr;
            func_map.erase(func_address);
        }
        // Reset the section's address in the address table
        section_addresses[section.index] = section.ram_addr;
        // Remove the section from the loaded section map
        loaded_sections.erase(find_it);
    }
}

extern "C" void load_overlay_by_id(uint32_t id, uint32_t ram_addr) {
    uint32_t section_table_index = overlays_info.table[id];
    const SectionTableEntry& section = sections_info.code_sections[section_table_index];
    int32_t prev_address = section_addresses[section.index];
    if (/*ram_addr >= 0x80000000 && ram_addr < 0x81000000) {*/ prev_address == section.ram_addr) {
        load_overlay(section_table_index, ram_addr);
    }
    else {
        int32_t new_address = prev_address + ram_addr;
        unload_overlay_by_id(id);
        load_overlay(section_table_index, new_address);
    }
}

// [wcw2k] WM2000 support (see Wm2kRecomp CLAUDE.md; upstream to the jessetbh fork's wcw
// branch alongside the [wcw fix] set).
//
// Boot-resident overlays: WM2000 stores its first two swap-overlays (rom 0x4C160/0x73390)
// INSIDE the IPL3 1MB boot image and block-copies them to their link addresses with the
// CPU instead of PI DMA, so the pi.cpp swap hook never sees a load. After the boot-window
// load, register every section that (a) lies fully inside the boot window, (b) does NOT
// land at its own address contiguously (those are fixed-segment splits the normal
// load_overlays call already handled), and (c) doesn't overlap another such candidate
// (Revenge's two overlays both live in-window at the SAME address — that game DMA-swaps
// them properly, so they must stay unregistered until the swap hook fires; this filter
// keeps WT/Revenge behavior byte-identical).
extern "C" void load_boot_resident_overlays(uint32_t boot_rom, int32_t boot_ram, uint32_t boot_size) {
    std::vector<size_t> cands;
    for (size_t i = 0; i < sections_info.num_code_sections; i++) {
        const SectionTableEntry& s = sections_info.code_sections[i];
        if (s.rom_addr < boot_rom || s.rom_addr + s.size > boot_rom + boot_size) continue;
        if ((int32_t)(s.rom_addr - boot_rom) + boot_ram == s.ram_addr) continue;
        cands.push_back(i);
    }
    for (size_t i : cands) {
        const SectionTableEntry& s = sections_info.code_sections[i];
        bool conflict = false;
        for (size_t j : cands) {
            if (j == i) continue;
            const SectionTableEntry& o = sections_info.code_sections[j];
            if (s.ram_addr < o.ram_addr + (int32_t)o.size && o.ram_addr < s.ram_addr + (int32_t)s.size) {
                conflict = true; break;
            }
        }
        if (conflict) continue;
        fprintf(stderr, "[wcw][ovl] boot-resident overlay rom=0x%06X registered at 0x%08X\n",
            s.rom_addr, (uint32_t)s.ram_addr);
        load_overlay(i, s.ram_addr);
    }
}

// [wcw2k] Generalized overlay swap for multi-slot AKI games (WM2000: slots 0x800E1B90 and
// 0x8011C900, four overlays, one of which spans both slots). If rom_off names a registered
// code section whose link address equals the DMA destination, swap it in: fully unload
// every loaded section overlapping the incoming range (unload_overlays' partial-overlap
// guard is correct for its other callers, but a swap legitimately clobbers a larger
// resident section), then load. Replaces pi.cpp's hardcoded dest==0x80090000 check;
// WT/Revenge behavior is unchanged (their swap sections' ram_addr IS 0x80090000).
extern "C" bool wcw_try_swap_overlay(uint32_t rom_off, int32_t ram_addr) {
    auto find_it = code_sections_by_rom.find(rom_off);
    if (find_it == code_sections_by_rom.end()) {
        return false;
    }
    size_t idx = find_it->second;
    const SectionTableEntry& s = sections_info.code_sections[idx];
    if (s.ram_addr != ram_addr) {
        return false;
    }
    for (auto it = loaded_sections.begin(); it != loaded_sections.end();) {
        const SectionTableEntry& ls = sections_info.code_sections[it->section_table_index];
        if (ram_addr < it->loaded_ram_addr + (int32_t)ls.size && it->loaded_ram_addr < ram_addr + (int32_t)s.size) {
            for (size_t fi = 0; fi < ls.num_funcs; fi++) {
                func_map.erase(it->loaded_ram_addr + ls.funcs[fi].offset);
            }
            section_addresses[ls.index] = ls.ram_addr;
            it = loaded_sections.erase(it);
        }
        else {
            ++it;
        }
    }
    load_overlay(idx, ram_addr);
    // [wcw2k] Child sections living INSIDE a parent overlay's rom image (hidden code
    // pockets/islands mapped as separate sections) are registered once at boot by
    // load_boot_resident_overlays, but a swap unloads them with the parent (overlap
    // sweep above) and reloading only the parent left them unregistered: boot91 died
    // with "Failed to find function at 0x80106928" (ovl_a's pocket) in the menus after
    // the first match, because the post-match ovl_a reload never re-registered it.
    // Re-register every child of the incoming overlay (skip if still loaded).
    static const struct { uint32_t parent_rom; uint32_t child_rom; } wcw2k_children[] = {
        { 0x4C160, 0x70EF8 },   // WM2000 ovl_a hidden code pocket (vram 0x80106928)
        { 0x809D0, 0xD0C2C },   // WM2000 ovl_c cold-path island  (vram 0x8016CB5C)
    };
    for (const auto& ch : wcw2k_children) {
        if (ch.parent_rom != rom_off) {
            continue;
        }
        auto child_it = code_sections_by_rom.find(ch.child_rom);
        if (child_it == code_sections_by_rom.end()) {
            continue;
        }
        size_t child_idx = child_it->second;
        bool already = false;
        for (const auto& ls : loaded_sections) {
            if (ls.section_table_index == child_idx) {
                already = true;
                break;
            }
        }
        if (!already) {
            const SectionTableEntry& cs = sections_info.code_sections[child_idx];
            fprintf(stderr, "[wcw2k][ovl] re-registering child section rom=0x%06X at 0x%08X\n",
                cs.rom_addr, (uint32_t)cs.ram_addr);
            load_overlay(child_idx, cs.ram_addr);
        }
    }
    return true;
}

extern "C" void unload_overlays(int32_t ram_addr, uint32_t size) {
    for (auto it = loaded_sections.begin(); it != loaded_sections.end();) {
        const auto& section = sections_info.code_sections[it->section_table_index];

        // Check if the unloaded region overlaps with the loaded section
        if (ram_addr < (it->loaded_ram_addr + section.size) && (ram_addr + size) >= it->loaded_ram_addr) {
            // Check if the section isn't entirely in the loaded region
            if (ram_addr > it->loaded_ram_addr || (ram_addr + size) < (it->loaded_ram_addr + section.size)) {
                fprintf(stderr,
                    "Cannot partially unload section\n"
                    "  rom: 0x%08X size: 0x%08X loaded_addr: 0x%08X\n"
                    "  unloaded_ram: 0x%08X unloaded_size : 0x%08X\n",
                        section.rom_addr, section.size, it->loaded_ram_addr, ram_addr, size);
                assert(false);
                std::exit(EXIT_FAILURE);
            }
            // Determine where each function was loaded to and remove that entry from the function map
            for (size_t func_index = 0; func_index < section.num_funcs; func_index++) {
                const auto& func = section.funcs[func_index];
                uint32_t func_address = func.offset + it->loaded_ram_addr;
                func_map.erase(func_address);
            }
            // Reset the section's address in the address table
            section_addresses[section.index] = section.ram_addr;
            // Remove the section from the loaded section map
            it = loaded_sections.erase(it);
            // Skip incrementing the iterator
            continue;
        }
        ++it;
    }
}

void recomp::overlays::init_overlays() {
    func_map.clear();
    section_addresses = (int32_t *)calloc(sections_info.total_num_sections, sizeof(int32_t));

    // Sort the executable sections by rom address
    std::sort(&sections_info.code_sections[0], &sections_info.code_sections[sections_info.num_code_sections],
        [](const SectionTableEntry& a, const SectionTableEntry& b) {
            return a.rom_addr < b.rom_addr;
        }
    );

    for (size_t section_index = 0; section_index < sections_info.num_code_sections; section_index++) {
        SectionTableEntry* code_section = &sections_info.code_sections[section_index];

        section_addresses[sections_info.code_sections[section_index].index] = code_section->ram_addr;
        code_sections_by_rom[code_section->rom_addr] = section_index;        
    }

    load_patch_functions();
}

// Finds a function given a section's index and the function's offset into the section.
bool recomp::overlays::get_func_entry_by_section_index_function_offset(uint16_t code_section_index, uint32_t function_offset, FuncEntry& func_out) {
    if (code_section_index >= sections_info.num_code_sections) {
        return false;
    }

    SectionTableEntry* section = &sections_info.code_sections[code_section_index];
    if (function_offset >= section->size) {
        return false;
    }
    
    // TODO avoid a linear lookup here.
    for (size_t func_index = 0; func_index < section->num_funcs; func_index++) {
        if (section->funcs[func_index].offset == function_offset) {
            func_out = section->funcs[func_index];
            return true;
        }
    }

    return false;
}

void recomp::overlays::register_manual_patch_symbols(const ManualPatchSymbol* manual_patch_symbols) {
    for (size_t i = 0; manual_patch_symbols[i].func != nullptr; i++) {
        if (!manual_patch_symbols_by_vram.emplace(manual_patch_symbols[i].ram_addr, manual_patch_symbols[i].func).second) {
            printf("Duplicate manual patch symbol address: %08X\n", manual_patch_symbols[i].ram_addr);
            ultramodern::error_handling::message_box("Duplicate manual patch symbol address (syms.ld)!");
            assert(false && "Duplicate manual patch symbol address (syms.ld)!");
            ultramodern::error_handling::quick_exit(__FILE__, __LINE__, __FUNCTION__);
        }
    }
}

// TODO use N64Recomp::is_manual_patch_symbol instead after updating submodule.
bool is_manual_patch_symbol(uint32_t vram) {
    return vram >= 0x8F000000 && vram < 0x90000000;
}

// Finds a function given a section's index and the function's offset into the section and returns its native pointer.
recomp_func_t* recomp::overlays::get_func_by_section_index_function_offset(uint16_t code_section_index, uint32_t function_offset) {
    FuncEntry entry;
    
    if (get_func_entry_by_section_index_function_offset(code_section_index, function_offset, entry)) {
        return entry.func;
    }

    if (code_section_index == N64Recomp::SectionAbsolute && is_manual_patch_symbol(function_offset)) {
        auto find_it = manual_patch_symbols_by_vram.find(function_offset);
        if (find_it != manual_patch_symbols_by_vram.end()) {
            return find_it->second;
        }
    }

    return nullptr;
}

// Finds a function given a section's rom address and the function's vram address.
recomp_func_t* recomp::overlays::get_func_by_section_rom_function_vram(uint32_t section_rom, uint32_t function_vram) {
    auto find_section_it = code_sections_by_rom.find(section_rom);
    if (find_section_it == code_sections_by_rom.end()) {
        return nullptr;
    }

    SectionTableEntry* section = &sections_info.code_sections[find_section_it->second];
    int32_t func_offset = function_vram - section->ram_addr;
    
    return get_func_by_section_index_function_offset(find_section_it->second, func_offset);
}

extern "C" recomp_func_t * get_function(int32_t addr) {
    auto func_find = func_map.find(addr);
    if (func_find == func_map.end()) {
        fprintf(stderr, "Failed to find function at 0x%08X\n", addr);
        assert(false);
        std::exit(EXIT_FAILURE);
    }
    return func_find->second;
}

std::unordered_map<recomp_func_t*, recomp::overlays::BasePatchedFunction> recomp::overlays::get_base_patched_funcs() {
    std::unordered_map<recomp_func_t*, BasePatchedFunction> ret{};

    // Collect the set of all functions in the patches.
    std::unordered_map<recomp_func_t*, BasePatchedFunction> all_patch_funcs{};
    for (size_t patch_section_index = 0; patch_section_index < num_patch_code_sections; patch_section_index++) {
        const auto& patch_section = patch_code_sections[patch_section_index];
        for (size_t func_index = 0; func_index < patch_section.num_funcs; func_index++) {
            all_patch_funcs.emplace(patch_section.funcs[func_index].func, BasePatchedFunction{ .patch_section = patch_section_index, .function_index = func_index });
        }
    }

    // Check every vanilla function against the full patch function set.
    // Any functions in both are patched.
    for (size_t code_section_index = 0; code_section_index < sections_info.num_code_sections; code_section_index++) {
        const auto& code_section = sections_info.code_sections[code_section_index];
        for (size_t func_index = 0; func_index < code_section.num_funcs; func_index++) {
            recomp_func_t* cur_func = code_section.funcs[func_index].func;
            // If this function also exists in the patches function set then it's a vanilla function that was patched.
            auto find_it = all_patch_funcs.find(cur_func);
            if (find_it != all_patch_funcs.end()) {
                ret.emplace(cur_func, find_it->second);
            }
        }
    }

    return ret;
}

const std::unordered_map<uint32_t, uint16_t>& recomp::overlays::get_patch_vrom_to_section_map() {
    return patch_code_sections_by_rom;
}

uint32_t recomp::overlays::get_patch_section_ram_addr(uint16_t patch_code_section_index) {
    if (patch_code_section_index < num_patch_code_sections) {
        return patch_code_sections[patch_code_section_index].ram_addr;
    }
    assert(false);
    return -1;
}

uint32_t recomp::overlays::get_patch_section_rom_addr(uint16_t patch_code_section_index) {
    if (patch_code_section_index < num_patch_code_sections) {
        return patch_code_sections[patch_code_section_index].rom_addr;
    }
    assert(false);
    return -1;
}

const FuncEntry* recomp::overlays::get_patch_function_entry(uint16_t patch_code_section_index, size_t function_index) {
    if (patch_code_section_index < num_patch_code_sections) {
        const auto& section = patch_code_sections[patch_code_section_index];
        if (function_index < section.num_funcs) {
            return &section.funcs[function_index];
        }
    }
    assert(false);
    return nullptr;
}

// Finds a base patched function given a patch section's index and the function's offset into the section.
bool recomp::overlays::get_patch_func_entry_by_section_index_function_offset(uint16_t patch_code_section_index, uint32_t function_offset, FuncEntry& func_out) {
    if (patch_code_section_index >= num_patch_code_sections) {
        return false;
    }

    SectionTableEntry* section = &patch_code_sections[patch_code_section_index];
    if (function_offset >= section->size) {
        return false;
    }
    
    // TODO avoid a linear lookup here.
    for (size_t func_index = 0; func_index < section->num_funcs; func_index++) {
        if (section->funcs[func_index].offset == function_offset) {
            func_out = section->funcs[func_index];
            return true;
        }
    }

    return false;
}

std::span<const RelocEntry> recomp::overlays::get_patch_section_relocs(uint16_t patch_code_section_index) {
    if (patch_code_section_index < num_patch_code_sections) {
        const auto& section = patch_code_sections[patch_code_section_index];
        return std::span{ section.relocs, section.num_relocs };
    }
    assert(false);
    return {};
}

std::span<const uint8_t> recomp::overlays::get_patch_binary() {
    return std::span{ reinterpret_cast<const uint8_t*>(patch_data.data()), patch_data.size() };
}

// [blitz][web] Copy of librecomp's overlays.cpp (WCW fork) for NFL Blitz, plus the swap below.
// Blitz's three overlays share vram 0x802AF750 and differ in size, its loaders DMA them in
// 0x4000-byte pieces, and the gameplay overlay's image starts with 0x4CC0 bytes of data
// before its code section. So no single DMA holds a whole code section, and
// load_overlays (whole sections only; its lower/upper search also runs past the table
// when a DMA lies inside one section) can't be used. Instead, per ROM DMA:
//  - drop each mapped section that the DMA overwrites with anything but its own image;
//  - map each code section that the DMA starts copying to its own link address. The
//    recompiled code doesn't read the bytes in RAM, so mapping before the last piece
//    lands is safe (the game only calls in once its loader has finished).
extern "C" void web_dma_overlays(uint32_t rom, int32_t ram_addr, uint32_t size) {
    const uint32_t delta = (uint32_t)ram_addr - rom;   // RAM-minus-ROM offset of this copy (mod 2^32)
    for (auto it = loaded_sections.begin(); it != loaded_sections.end();) {
        const SectionTableEntry& ls = sections_info.code_sections[it->section_table_index];
        bool overlaps = ram_addr < it->loaded_ram_addr + (int32_t)ls.size && it->loaded_ram_addr < ram_addr + (int32_t)size;
        bool own_image = (uint32_t)it->loaded_ram_addr - ls.rom_addr == delta;
        if (overlaps && !own_image) {
            RV_TRACE(stderr, "[ovl] unload section rom 0x%X at 0x%08X (DMA rom 0x%X -> 0x%08X size 0x%X)\n", ls.rom_addr, (uint32_t)it->loaded_ram_addr, rom, (uint32_t)ram_addr, size);
            for (size_t fi = 0; fi < ls.num_funcs; fi++) {
                func_map.erase(it->loaded_ram_addr + ls.funcs[fi].offset);
            }
            section_addresses[ls.index] = ls.ram_addr;
            it = loaded_sections.erase(it);
        }
        else {
            ++it;
        }
    }
    for (size_t i = 0; i < sections_info.num_code_sections; i++) {
        const SectionTableEntry& s = sections_info.code_sections[i];
        if (s.rom_addr >= rom + size || rom >= s.rom_addr + s.size) continue;      // not in this DMA
        if ((uint32_t)s.ram_addr - s.rom_addr != delta) continue;                    // not to its link address
        bool loaded = false;
        for (const auto& ls : loaded_sections) loaded |= ls.section_table_index == i;
        if (!loaded) { RV_TRACE(stderr, "[ovl] load section rom 0x%X at 0x%08X\n", s.rom_addr, (uint32_t)s.ram_addr); load_overlay(i, s.ram_addr); }
    }
}
