/* Web build: miniz is not compiled in; only its header is seen (via mods.hpp). */
#ifndef MINIZ_EXPORT
#define MINIZ_EXPORT
#endif
