// Web build glue shared between the cooperative runtime files and web_main.cpp.
#pragma once
#include <cstdint>
#include "coop.hpp"

// coop_events.cpp
void web_vi_tick();        // one 60 Hz retrace: VI/AI events, VI register update
bool web_process_gfx();    // hand queued display lists to the renderer; true if any ran
void web_present();        // show the newest scanout state (once per browser frame)
extern uint64_t web_total_vis, web_gfx_tasks, web_audio_tasks;

// coop_timer.cpp
void coop_service_timers();

// web_pi.cpp
bool web_save_dirty();                       // the save changed since the last call
const uint8_t* web_save_data(uint32_t* size);
void web_save_load(const uint8_t* data, uint32_t size);
