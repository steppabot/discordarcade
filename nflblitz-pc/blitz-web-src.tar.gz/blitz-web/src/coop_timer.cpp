// Web build copy of ultramodern timer.cpp: timers are serviced by the frame loop.
#include <vector>
#include <thread>
#include <variant>
#include <set>
#include "blockingconcurrentqueue.h"

#include "ultramodern/ultra64.h"
#include "ultramodern/ultramodern.hpp"

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include "Windows.h"
#endif

// Start time for the program
static std::chrono::high_resolution_clock::time_point start_time = std::chrono::high_resolution_clock::now();
// Offset of the duration since program start used to calculate the value for osGetTime. 
static int64_t ostime_offset = 0;
// Game speed multiplier (1 means no speedup)
constexpr uint32_t speed_multiplier = 1;
// N64 CPU counter ticks per millisecond
constexpr uint32_t counter_per_ms = 46'875 * speed_multiplier;

struct OSTimer {
    PTR(OSTimer) unused1;
    PTR(OSTimer) unused2;
    OSTime interval;
    OSTime timestamp;
    PTR(OSMesgQueue) mq;
    OSMesg msg;
};

struct AddTimerAction {
    PTR(OSTimer) timer;
};

struct RemoveTimerAction {
    PTR(OSTimer) timer;
};

// [wcw fix] Ends the timer thread at shutdown (aki-roadmap#3): it reads OSTimers in rdram, so it
// has to stop before rdram is released. It used to be detached and run forever.
struct ExitTimerAction {};

using Action = std::variant<AddTimerAction, RemoveTimerAction, ExitTimerAction>;

struct {
    moodycamel::BlockingConcurrentQueue<Action> action_queue{};
} timer_context;

uint64_t duration_to_ticks(std::chrono::high_resolution_clock::duration duration) {
    uint64_t delta_micros = std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    // More accurate than using a floating point timer, will only overflow after running for 12.47 years
    // Units: (micros * (counts/millis)) / (micros/millis) = counts
    uint64_t total_count = (delta_micros * counter_per_ms) / 1000;

    return total_count;
}

std::chrono::microseconds ticks_to_duration(uint64_t ticks) {
    using namespace std::chrono_literals;
    return ticks * 1000us / counter_per_ms;
}

std::chrono::high_resolution_clock::time_point ticks_to_timepoint(uint64_t ticks) {
    return start_time + ticks_to_duration(ticks);
}

uint64_t time_now() {
    return duration_to_ticks(std::chrono::high_resolution_clock::now() - start_time);
}

// Web: no timer thread. The frame loop calls coop_service_timers() each pass; due timers
// post their message (as the timer thread did) and periodic ones are reloaded.
static uint8_t* timer_rdram = nullptr;
static std::vector<PTR(OSTimer)> active_timers;

void coop_service_timers() {
    uint8_t* rdram = timer_rdram;
    if (rdram == nullptr) {
        return;
    }
    Action cur_action;
    while (timer_context.action_queue.try_dequeue(cur_action)) {
        if (const auto* add_action = std::get_if<AddTimerAction>(&cur_action)) {
            std::erase(active_timers, add_action->timer); // re-arming an active timer
            active_timers.push_back(add_action->timer);
        } else if (const auto* remove_action = std::get_if<RemoveTimerAction>(&cur_action)) {
            std::erase(active_timers, remove_action->timer);
        }
    }
    uint64_t now = time_now();
    // Fire in timestamp order, a bounded number of times per pass.
    for (int guard = 0; guard < 64; guard++) {
        PTR(OSTimer) due_ = NULLPTR;
        for (PTR(OSTimer) t_ : active_timers) {
            OSTimer* t = TO_PTR(OSTimer, t_);
            if (t->timestamp <= now && (due_ == NULLPTR || t->timestamp < TO_PTR(OSTimer, due_)->timestamp)) {
                due_ = t_;
            }
        }
        if (due_ == NULLPTR) {
            break;
        }
        OSTimer* due = TO_PTR(OSTimer, due_);
        std::erase(active_timers, due_);
        ultramodern::enqueue_external_message(due->mq, due->msg, false, true);
        if (due->interval != 0) {
            due->timestamp = due->interval + now;
            active_timers.push_back(due_);
        }
    }
}

void ultramodern::init_timers(RDRAM_ARG1) {
    timer_rdram = rdram;
}

void ultramodern::join_timer_thread() {
}

uint32_t ultramodern::get_speed_multiplier() {
    return speed_multiplier;
}

std::chrono::high_resolution_clock::time_point ultramodern::get_start() {
    return start_time;
}

std::chrono::high_resolution_clock::duration ultramodern::time_since_start() {
    return std::chrono::high_resolution_clock::now() - start_time;
}

extern "C" u32 osGetCount() {
    uint64_t total_count = time_now();

    // Allow for overflows, which is how osGetCount behaves
    return (uint32_t)total_count;
}

extern "C" void osSetCount(u32 count) {
    assert(false);
}

extern "C" OSTime osGetTime() {
    uint64_t total_count = time_now() - ostime_offset;

    return total_count;
}

extern "C" void osSetTime(OSTime t) {
    ostime_offset = time_now() - t;
}

extern "C" int osSetTimer(RDRAM_ARG PTR(OSTimer) t_, OSTime countdown, OSTime interval, PTR(OSMesgQueue) mq, OSMesg msg) {
    OSTimer* t = TO_PTR(OSTimer, t_);

    // Determine the time when this timer will trigger off
    if (countdown == 0) {
        // Set the timestamp based on the interval
        t->timestamp = interval + time_now();
    } else {
        t->timestamp = countdown + time_now();
    }
    t->interval = interval;
    t->mq = mq;
    t->msg = msg;

    // [wcw] identify who registers periodic timers (they keep firing into full queues post-freeze)
    {
        static int n = 0;
        if (n++ < 30) fprintf(stderr, "[wcw][osSetTimer] t=0x%X countdown=%llu interval=%llu mq=0x%X msg=0x%X\n",
            (unsigned)(uint32_t)t_, (unsigned long long)countdown, (unsigned long long)interval,
            (unsigned)(uint32_t)mq, (unsigned)(uint32_t)msg);
    }

    timer_context.action_queue.enqueue(AddTimerAction{ t_ });

    return 0;
}

extern "C" int osStopTimer(RDRAM_ARG PTR(OSTimer) t_) {
    timer_context.action_queue.enqueue(RemoveTimerAction{ t_ });

    // TODO don't blindly return 0 here; requires some response from the timer thread to know what the returned value was
    return 0;
}

// Web: there is no thread to put to sleep. A game thread gives the browser its frame
// instead; anywhere else these return at once.
void coop_yield_to_main();

void ultramodern::sleep_milliseconds(uint32_t millis) {
    coop_yield_to_main();
}

void ultramodern::sleep_until(const std::chrono::high_resolution_clock::time_point& time_point) {
    if (time_point > std::chrono::high_resolution_clock::now()) {
        coop_yield_to_main();
    }
}
