// Web build of ultramodern events.cpp. There are no VI, gfx or RSP task threads: the
// browser frame loop calls web_vi_tick() once per due 60 Hz retrace, runs the game, and
// calls web_process_gfx() to hand queued display lists to the renderer and
// web_present() once per browser frame. Audio RSP tasks run inline when submitted.
// VI state handling (double-buffered ViState, WCW's retrace fixes) is kept from the
// original file.
#include <atomic>
#include <chrono>
#include <cinttypes>
#include <cstring>
#include <deque>
#include <memory>

#include "ultramodern/ultra64.h"
#include "ultramodern/ultramodern.hpp"
#include "ultramodern/extensions.h"

#include "ultramodern/rsp.hpp"
#include "ultramodern/renderer_context.hpp"

#include "web.hpp"

static ultramodern::events::callbacks_t events_callbacks{};

void ultramodern::events::set_callbacks(const ultramodern::events::callbacks_t& callbacks) {
    events_callbacks = callbacks;
}

struct ViState {
    const OSViMode* mode;
    PTR(void) framebuffer;
    PTR(OSMesgQueue) mq;
    OSMesg msg;
    uint32_t state;
    uint32_t control;
    int retrace_count = 1;
};

#define VI_STATE_BLACK 0x20
#define VI_STATE_REPEATLINE 0x40

static struct {
    struct {
        int cur_state;
        int field;
        ViState states[2];
        ultramodern::renderer::ViRegs regs;
        ultramodern::renderer::ViRegs update_screen_regs;

        ViState* get_next_state() { return &states[cur_state ^ 1]; }
        ViState* get_cur_state() { return &states[cur_state]; }

        void update_vi() {
            ViState* next_state = get_next_state();
            const OSViMode* next_mode = next_state->mode;
            if (next_mode == nullptr) {
                return;
            }
            const OSViCommonRegs* common_regs = &next_mode->comRegs;
            const OSViFieldRegs* field_regs = &next_mode->fldRegs[field];
            PTR(void) framebuffer = osVirtualToPhysical(next_state->framebuffer);
            PTR(void) origin = framebuffer + field_regs->origin;
            uint32_t hStart = common_regs->hStart;
            if (next_state->state & VI_STATE_BLACK) {
                hStart = 0;
            }
            uint32_t yScale = field_regs->yScale;
            if (next_state->state & VI_STATE_REPEATLINE) {
                yScale = 0;
                origin = framebuffer;
            }
            regs.VI_ORIGIN_REG = origin;
            regs.VI_WIDTH_REG = common_regs->width;
            regs.VI_TIMING_REG = common_regs->burst;
            regs.VI_V_SYNC_REG = common_regs->vSync;
            regs.VI_H_SYNC_REG = common_regs->hSync;
            regs.VI_LEAP_REG = common_regs->leap;
            regs.VI_H_START_REG = hStart;
            regs.VI_V_START_REG = field_regs->vStart;
            regs.VI_V_BURST_REG = field_regs->vBurst;
            regs.VI_INTR_REG = field_regs->vIntr;
            regs.VI_X_SCALE_REG = common_regs->xScale;
            regs.VI_Y_SCALE_REG = yScale;
            regs.VI_STATUS_REG = next_state->control;

            cur_state ^= 1;
            *get_next_state() = *get_cur_state();
        }
    } vi;
    struct { PTR(OSMesgQueue) mq = NULLPTR; OSMesg msg = (OSMesg)0; } sp, dp, ai, si;
    uint8_t* rdram;
    std::unique_ptr<ultramodern::renderer::RendererContext> renderer;
    std::deque<OSTask> gfx_tasks;
    bool screen_pending = false;
    ultramodern::renderer::ViRegs screen_regs{};
    bool dummy_pending = false;
    uint32_t dummy_fb = 0;
    int remaining_retraces = 1;
} events_context{};

// Read by mesgqueue.cpp's (disabled) health line.
std::atomic_int wcw_viswaps{0};

ultramodern::renderer::ViRegs* ultramodern::renderer::get_vi_regs() {
    return &events_context.vi.update_screen_regs;
}

extern "C" void osSetEventMesg(RDRAM_ARG OSEvent event_id, PTR(OSMesgQueue) mq_, OSMesg msg) {
    switch (event_id) {
        case OS_EVENT_SP: events_context.sp.msg = msg; events_context.sp.mq = mq_; break;
        case OS_EVENT_DP: events_context.dp.msg = msg; events_context.dp.mq = mq_; break;
        case OS_EVENT_AI: events_context.ai.msg = msg; events_context.ai.mq = mq_; break;
        case OS_EVENT_SI: events_context.si.msg = msg; events_context.si.mq = mq_; break;
    }
}

extern "C" void osViSetEvent(RDRAM_ARG PTR(OSMesgQueue) mq_, OSMesg msg, u32 retrace_count) {
    // [wcw fix] The retrace registration is global on hardware: set it on both VI states.
    for (ViState* s : { events_context.vi.get_next_state(), events_context.vi.get_cur_state() }) {
        s->mq = mq_;
        s->msg = msg;
        s->retrace_count = retrace_count;
    }
}

static const OSViMode dummy_mode = []() {
    OSViMode ret{};
    ret.type = 2;
    ret.comRegs.ctrl = 0x00002 | 0x00004 | 0x00008 | 0x00010 | 0x00100 | 0x03000;
    ret.comRegs.width = 0x140;
    ret.comRegs.burst = 0x03E52239;
    ret.comRegs.vSync = 0x20D;
    ret.comRegs.hSync = 0xC15;
    ret.comRegs.leap = 0x0C150C15;
    ret.comRegs.hStart = 0x006C02EC;
    ret.comRegs.xScale = 0x200;
    ret.comRegs.vCurrent = 0x0;
    for (int field = 0; field < 2; field++) {
        ret.fldRegs[field].origin = 0x280;
        ret.fldRegs[field].yScale = 0x400;
        ret.fldRegs[field].vStart = 0x2501FF;
        ret.fldRegs[field].vBurst = 0xE0204;
        ret.fldRegs[field].vIntr = 0x2;
    }
    return ret;
}();

static void set_dummy_vi(bool odd) {
    ViState* next_state = events_context.vi.get_next_state();
    next_state->mode = &dummy_mode;
    next_state->control = next_state->mode->comRegs.ctrl;
    next_state->framebuffer = 0x80700000 + (odd ? 0x25800 : 0);
}

uint64_t web_total_vis = 0;

void web_vi_tick() {
    web_total_vis++;
    if (!ultramodern::is_game_started()) {
        static bool odd = false;
        set_dummy_vi(odd);
        odd = !odd;
        events_context.dummy_pending = true;
        events_context.dummy_fb = events_context.vi.get_next_state()->framebuffer;
    }

    // The screen shows the scanout state from before this retrace's VI update, as in
    // the original (only the newest snapshot is presented).
    events_context.screen_regs = events_context.vi.regs;
    events_context.screen_pending = true;

    events_context.vi.update_vi();

    if (ultramodern::is_game_started()) {
        int& remaining = events_context.remaining_retraces;
        remaining--;
        ViState* cur_state = events_context.vi.get_cur_state();
        // [wcw fix] `<= 0` with a clamped reload (a 0 retrace count read mid-swap used to stop
        // retrace events for good).
        if (remaining <= 0) {
            if (cur_state->mq != NULLPTR) {
                ultramodern::enqueue_external_message(cur_state->mq, cur_state->msg, false, false);
            }
            remaining = (cur_state->retrace_count > 0) ? cur_state->retrace_count : 1;
        }
        if (events_context.ai.mq != NULLPTR) {
            ultramodern::enqueue_external_message(events_context.ai.mq, events_context.ai.msg, false, false);
        }
    }

    if (events_callbacks.vi_callback != nullptr) {
        events_callbacks.vi_callback();
    }
}

static void sp_complete() {
    ultramodern::enqueue_external_message(events_context.sp.mq, events_context.sp.msg, false, true);
}

static void dp_complete() {
    ultramodern::enqueue_external_message(events_context.dp.mq, events_context.dp.msg, false, true);
}

uint64_t web_gfx_tasks = 0, web_audio_tasks = 0;

bool web_process_gfx() {
    bool any = false;
    auto& r = events_context.renderer;
    if (events_context.dummy_pending) {
        events_context.dummy_pending = false;
        if (r) r->send_dummy_workload(events_context.dummy_fb);
    }
    while (!events_context.gfx_tasks.empty()) {
        OSTask task = events_context.gfx_tasks.front();
        events_context.gfx_tasks.pop_front();
        PTR(u64) displaylist = task.t.data_ptr;
        ultramodern::extensions::on_displaylist_submitted(displaylist);
        if (r) r->send_dl(&task);
        // [wcw fix] SP done only after the display list was consumed (hardware contract).
        sp_complete();
        dp_complete();
        ultramodern::extensions::on_displaylist_parsed(displaylist);
        ultramodern::extensions::on_displaylist_completed(displaylist);
        web_gfx_tasks++;
        any = true;
    }
    return any;
}

void web_present() {
    if (!events_context.screen_pending) {
        return;
    }
    events_context.screen_pending = false;
    events_context.vi.update_screen_regs = events_context.screen_regs;
    if (events_context.renderer) {
        events_context.renderer->update_screen();
    }
}

uint32_t ultramodern::get_target_framerate(uint32_t original) {
    return original;
}

uint32_t ultramodern::get_display_refresh_rate() {
    return 60;
}

float ultramodern::get_resolution_scale() {
    return events_context.renderer ? events_context.renderer->get_resolution_scale() : 1.0f;
}

void ultramodern::trigger_config_action() {
}

extern "C" void osViSwapBuffer(RDRAM_ARG PTR(void) frameBufPtr) {
    wcw_viswaps.fetch_add(1);
    events_context.vi.get_next_state()->framebuffer = frameBufPtr;
}

extern "C" void osViSetMode(RDRAM_ARG PTR(OSViMode) mode_) {
    OSViMode* mode = TO_PTR(OSViMode, mode_);
    ViState* next_state = events_context.vi.get_next_state();
    next_state->mode = mode;
    next_state->control = next_state->mode->comRegs.ctrl;
}

#define VI_CTRL_GAMMA_DITHER_ON     0x00004
#define VI_CTRL_GAMMA_ON            0x00008
#define VI_CTRL_DIVOT_ON            0x00010
#define VI_CTRL_ANTIALIAS_MASK      0x00300
#define VI_CTRL_DITHER_FILTER_ON    0x10000

#define OS_VI_GAMMA_ON          0x0001
#define OS_VI_GAMMA_OFF         0x0002
#define OS_VI_GAMMA_DITHER_ON   0x0004
#define OS_VI_GAMMA_DITHER_OFF  0x0008
#define OS_VI_DIVOT_ON          0x0010
#define OS_VI_DIVOT_OFF         0x0020
#define OS_VI_DITHER_FILTER_ON  0x0040
#define OS_VI_DITHER_FILTER_OFF 0x0080

extern "C" void osViSetSpecialFeatures(uint32_t func) {
    ViState* next_state = events_context.vi.get_next_state();
    uint32_t* c = &next_state->control;
    if (func & OS_VI_GAMMA_ON) *c |= VI_CTRL_GAMMA_ON;
    if (func & OS_VI_GAMMA_OFF) *c &= ~VI_CTRL_GAMMA_ON;
    if (func & OS_VI_GAMMA_DITHER_ON) *c |= VI_CTRL_GAMMA_DITHER_ON;
    if (func & OS_VI_GAMMA_DITHER_OFF) *c &= ~VI_CTRL_GAMMA_DITHER_ON;
    if (func & OS_VI_DIVOT_ON) *c |= VI_CTRL_DIVOT_ON;
    if (func & OS_VI_DIVOT_OFF) *c &= ~VI_CTRL_DIVOT_ON;
    if (func & OS_VI_DITHER_FILTER_ON) {
        *c |= VI_CTRL_DITHER_FILTER_ON;
        *c &= ~VI_CTRL_ANTIALIAS_MASK;
    }
    if (func & OS_VI_DITHER_FILTER_OFF) {
        *c &= ~VI_CTRL_DITHER_FILTER_ON;
        if (next_state->mode) *c |= next_state->mode->comRegs.ctrl & VI_CTRL_ANTIALIAS_MASK;
    }
}

extern "C" void osViBlack(uint8_t active) {
    uint32_t* s = &events_context.vi.get_next_state()->state;
    if (active) *s |= VI_STATE_BLACK; else *s &= ~VI_STATE_BLACK;
}

extern "C" void osViRepeatLine(uint8_t active) {
    uint32_t* s = &events_context.vi.get_next_state()->state;
    if (active) *s |= VI_STATE_REPEATLINE; else *s &= ~VI_STATE_REPEATLINE;
}

extern "C" void osViSetXScale(float scale) {
}

extern "C" void osViSetYScale(float scale) {
}

extern "C" PTR(void) osViGetNextFramebuffer() {
    return events_context.vi.get_next_state()->framebuffer;
}

extern "C" PTR(void) osViGetCurrentFramebuffer() {
    return events_context.vi.get_cur_state()->framebuffer;
}

void ultramodern::submit_rsp_task(RDRAM_ARG PTR(OSTask) task_) {
    OSTask* task = TO_PTR(OSTask, task_);
    if (task->t.type == M_GFXTASK) {
        // Rendered from the frame loop, outside the game fibers.
        events_context.gfx_tasks.push_back(*task);
        return;
    }
    // Audio (and any other) task: recompiled RSP microcode, run right away.
    if (!ultramodern::rsp::run_task(PASS_RDRAM task)) {
        fprintf(stderr, "Failed to execute task type: %" PRIu32 "\n", task->t.type);
    }
    web_audio_tasks++;
    sp_complete();
}

void ultramodern::send_si_message() {
    ultramodern::enqueue_external_message(events_context.si.mq, events_context.si.msg, false, true);
}

void ultramodern::init_events(RDRAM_ARG ultramodern::renderer::WindowHandle window_handle) {
    events_context.rdram = rdram;
    events_context.renderer = ultramodern::renderer::create_render_context(rdram, window_handle, false);
    if (!events_context.renderer || !events_context.renderer->valid()) {
        fprintf(stderr, "[web] renderer failed to start\n");
        events_context.renderer.reset();
    } else if (events_callbacks.gfx_init_callback != nullptr) {
        events_callbacks.gfx_init_callback();
    }
    ultramodern::rsp::init();
}

void ultramodern::join_event_threads() {
}
