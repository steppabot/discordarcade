// Defaults for the page hooks, so the build also runs headless (node tests). The page
// replaces these with its AudioWorklet queue, saves and pads.
(function () {
  var now = function () { return (typeof performance !== 'undefined' ? performance : Date).now(); };
  var sim = { rate: 32000, queued: 0, t: 0 };
  function drain() {
    var t = now();
    if (sim.t) sim.queued = Math.max(0, sim.queued - (t - sim.t) * sim.rate / 1000);
    sim.t = t;
  }
  Module.rvAudioInit = Module.rvAudioInit || function (rate) { sim.rate = rate; Module.rvAudioRate = rate; };
  Module.rvAudioPush = Module.rvAudioPush || function (view) { drain(); sim.queued += view.length / 2; Module.rvAudioFrames = (Module.rvAudioFrames || 0) + view.length / 2; };
  Module.rvAudioQueued = Module.rvAudioQueued || function () { drain(); return Math.round(sim.queued); };
})();
