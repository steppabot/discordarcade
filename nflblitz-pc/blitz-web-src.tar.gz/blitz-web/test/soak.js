// Soak test: boot the web build in node (no GL), fast-forward the clock, walk the menus
// into an Arcade game and mash random controls until the time runs out or the game
// crashes. On a crash it prints the reason, the last runtime messages and the stack.
//   node soak.js <virtual minutes> [seed] [speed]
const fs = require('fs');
const minutes = +(process.argv[2] || 15), seed0 = +(process.argv[3] || 1), SPEED = +(process.argv[4] || 4);
const rom = fs.readFileSync('/home/claude/blitz/nflblitz.z64');

// Virtual clock: SPEED times real time, for every timer the runtime reads.
const realNow = performance.now.bind(performance), r0 = realNow(), d0 = Date.now();
const vnow = () => (realNow() - r0) * SPEED;
performance.now = vnow;
Date.now = () => d0 + vnow();

let seed = seed0, curOvl = '', ovlSince = 0, games = 0;
const NEWGAMES = !!process.env.NEWGAMES;   // keep starting new games from the menus
const rnd = () => ((seed = (seed * 1103515245 + 12345) >>> 0) / 4294967296);
const tail = [];
const note = t => { tail.push(t); if (tail.length > 60) tail.shift(); };
function report(kind, what) {
  console.log(`\n=== ${kind} at virtual ${(vnow() / 1000).toFixed(1)} s (vis ${Module._rv_stat ? Module._rv_stat(0) : '?'}) ===`);
  console.log(String(what && what.stack || what));
  console.log('full games before this: ' + games);
  console.log('--- last runtime messages ---\n' + tail.join('\n'));
  process.exit(2);
}
process.on('uncaughtException', e => report('EXCEPTION', e));

// Menu walk (virtual seconds, button bits), then mashing.
const A = 0x8000, B = 0x4000, Z = 0x2000, START = 0x1000, R = 0x0010, CU = 0x0008, CD = 0x0004, CL = 0x0002, CR = 0x0001;
const script = [[8, START], [14, START], [22, A], [27, A], [32, A], [36, A], [40, A], [44, A], [48, A], [52, A]];

global.Module = {
  print: t => note(t),
  printErr: t => {
    if (t.startsWith('[dma]')) {   // overlay swaps at 0x802AF750 mark menus / game / other screens
      const m = / phys=0x([0-9A-F]+) ram=0x802AF750 /.exec(t);
      if (m) { const ovl0 = { '10068890': 'ovl_68890', '1006E3D0': 'menus', '100A8710': 'game' }[m[1]] || m[1]; if (ovl0 !== curOvl) { if (curOvl === 'game' && vnow() - ovlSince > 180000) games++; curOvl = ovl0; ovlSince = vnow(); } const ovl = { '10068890': 'ovl_68890', '1006E3D0': 'menus', '100A8710': 'game' }[m[1]] || m[1]; console.log(`  overlay ${ovl} at ${(vnow() / 1000).toFixed(0)} s`); note('overlay ' + ovl); }
      return;
    }
    if (/^\[ovl\]|^\[wcw/.test(t)) return; note(t);
  },
  preRun: [() => { const F = Module.FS || FS; F.mkdir('/rom'); F.writeFile('/rom/blitz.z64', rom); }],
  rvNoGL: true, bzDmaLog: true,
  rvStarted: () => {
    let held = 0, until = 0, sx = 0, sy = 0, stickUntil = 0, lastStat = 0;
    const tick = () => {
      const t = vnow() / 1000;
      let b = 0;
      while (script.length && script[0][0] <= t) { held = script.shift()[1]; until = t + 0.15; }
      if (t > 56) {
        // Mash: a button every ~0.4 s (no Start: it pauses), the stick somewhere random.
        if (NEWGAMES && curOvl !== 'game' && t >= until + 0.25 && rnd() < 0.3) { held = START; until = t + 0.15; }
        else if (t >= until + 0.25) { held = [A, A, B, B, CU, CD, CL, CR, Z, R][Math.floor(rnd() * 10)]; until = t + 0.08 + rnd() * 0.5; }
        if (t >= stickUntil) { const a = rnd() * 2 * Math.PI, m = rnd() < 0.2 ? 0 : 80; sx = Math.round(Math.cos(a) * m); sy = Math.round(Math.sin(a) * m); stickUntil = t + 0.3 + rnd() * 1.5; }
      }
      if (t < until) b |= held;
      Module._rv_set_pad(0, b, sx, sy);
      if (t - lastStat >= 30) { lastStat = t; console.log(`t=${t.toFixed(0)} vis=${Module._rv_stat(0)} gfx=${Module._rv_stat(1)} audio=${Module._rv_stat(2)} pak=${Module._rv_stat(6)}/${Module._rv_stat(7)} threads=${Module._rv_stat(8)} stacks=${Module._rv_stat(9)} reused=${Module._rv_stat(10)} mem=${(Module.HEAPU8.length >> 20)}MB`); }
      Module._rv_frame();
      if (t < minutes * 60) return setImmediate(tick);
      console.log(`OK ${minutes} virtual minutes, vis ${Module._rv_stat(0)}, long game-overlay stretches (full games) ${games}`);
      process.exit(0);
    };
    setImmediate(tick);
  },
  onAbort: w => report('ABORT', new Error(String(w))),
};
global.require = require; global.__dirname = '/home/claude/bzweb/build'; global.__filename = '/home/claude/bzweb/build/blitz.js';
require('vm').runInThisContext(fs.readFileSync('/home/claude/bzweb/build/blitz.js', 'utf8'), { filename: 'blitz.js' });
