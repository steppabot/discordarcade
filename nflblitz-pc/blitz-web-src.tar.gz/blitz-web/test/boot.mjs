// Boot NFL Blitz in Chromium (SwiftShader WebGL2): click Start, screenshot at given times,
// print the console log and the runtime's frame statistics.
// usage: boot.mjs secs outprefix t1,t2,...   (KEYS="t:down:Key;..." optional input script)
import { createRequire } from 'module';
const { chromium } = createRequire(import.meta.url)('playwright');
const secs = +(process.argv[2] || 20), out = process.argv[3] || '/home/claude/bzweb/test/out/s';
const shots = (process.argv[4] || '').split(',').filter(Boolean).map(Number);
const keys = (process.env.KEYS || '').split(';').filter(Boolean).map(s => s.split(':')).map(([t, k, c]) => [+t, k, c]);
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required'] });
const page = await browser.newPage({ viewport: { width: 800, height: 700 } });
const logs = [];
page.on('console', m => { if (logs.length < 3000) logs.push(m.type() + ' ' + m.text().slice(0, 300)); });
page.on('pageerror', e => logs.push('PAGEERROR ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 25).join('\n')));
await page.goto('http://127.0.0.1:8766/nflblitz-pc/index.html' + (process.env.Q || ''));
await page.waitForSelector('#start:not([disabled])', { timeout: 60000 });
await page.click('#start');
await page.waitForFunction(() => document.documentElement.classList.contains('running') || document.documentElement.classList.contains('err'), null, { timeout: 120000 }).catch(() => {});
const t0 = Date.now(); const pending = [...shots];
while ((Date.now() - t0) / 1000 < secs) {
  const t = (Date.now() - t0) / 1000;
  while (keys.length && keys[0][0] <= t) { const [, k, c] = keys.shift(); if (k === 'down') await page.keyboard.down(c); else await page.keyboard.up(c); }
  if (pending.length && pending[0] <= t) { const s = pending.shift(); await page.locator('#canvas').screenshot({ path: `${out}-${String(s).padStart(3, '0')}.png` }).catch(() => {}); }
  if (process.env.STAT && Math.floor(t / 2) !== Math.floor((t - 0.1) / 2)) logs.push('t=' + t.toFixed(1) + ' ' + JSON.stringify(await page.evaluate(() => [Module._rv_stat(0), Module._rv_stat(1), Module._rv_stat(2), Module._rv_stat(6), Module._rv_stat(7), Module._rv_stat(8)]).catch(() => null)));
  await page.waitForTimeout(100);
}
if (process.env.DUMP) { await page.evaluate(() => Module._rv_dump_threads()).catch(() => {}); await page.waitForTimeout(300); }
if (process.env.KEYSOUT) {
  const keys = await page.evaluate(() => {
    const p = Module._malloc(8 * 4096), n = Module._rv_glide_keys(p, 4096), out = [];
    const u = new Uint32Array(Module.HEAPU8.buffer, p, 2 * Math.min(n, 4096));
    for (let i = 0; i < Math.min(n, 4096); i++) out.push('0x' + u[2 * i + 1].toString(16).padStart(8, '0') + u[2 * i].toString(16).padStart(8, '0'));
    Module._free(p); return out;
  }).catch(() => []);
  const fs = createRequire(import.meta.url)('fs'), f = process.env.KEYSOUT;
  const all = new Set(fs.existsSync(f) ? fs.readFileSync(f, 'utf8').split('\n').filter(Boolean) : []);
  const before = all.size; for (const k of keys) all.add(k);
  fs.writeFileSync(f, [...all].sort().join('\n') + '\n');
  logs.push(`KEYS this run ${keys.length}, new ${all.size - before}, total ${all.size}`);
}
const stats = await page.evaluate(() => window.Module && Module._rv_stat ? { vis: Module._rv_stat(0), gfx: Module._rv_stat(1), audio: Module._rv_stat(2), msGame: Math.round(Module._rv_stat(3)), msGfx: Math.round(Module._rv_stat(4)), msPresent: Math.round(Module._rv_stat(5)) } : null).catch(e => 'eval failed: ' + e.message);
console.log(logs.join('\n'));
console.log('STATUS', await page.evaluate(() => document.getElementById('status').textContent).catch(() => '?'));
console.log('STATS', JSON.stringify(stats));
await browser.close();
