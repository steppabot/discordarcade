// Boot the web build in node with the null renderer and report progress.
const fs = require('fs');
const path = require('path');
const secs = +(process.argv[2] || 10);
const rom = fs.readFileSync('/home/claude/blitz/nflblitz.z64');
let lines = 0;
global.Module = {
  print: t => { if (lines++ < 2000) console.log(t); },
  printErr: t => { if (/^\[ovl\]|^\[wcw/.test(t) && !process.env.ALLLOG) return; if (lines++ < 2000) console.error(t); },
  preRun: [() => { console.log('prerun', typeof FS, typeof Module.FS); const F = Module.FS || FS; F.mkdir('/rom'); F.writeFile('/rom/blitz.z64', rom); console.log('wrote', F.stat('/rom/blitz.z64').size); }],
  rvNoGL: true, bzDmaLog: !!process.env.DMALOG, bzPakLog: !!process.env.PAKLOG,
  rvStarted: () => {
    const t0 = Date.now();
    let frames = 0, lastStat = 0;
    // KEYS="t:hexbuttons;..." sets pad 0's N64 buttons at t seconds (Start 1000, A 8000, B 4000).
    const keys = (process.env.KEYS || '').split(';').filter(Boolean).map(s => s.split(':')).map(([t, b]) => [+t, parseInt(b, 16)]);
    const tick = () => {
      const t = (Date.now() - t0) / 1000;
      while (keys.length && keys[0][0] <= t) Module._rv_set_pad(0, keys.shift()[1], 0, 0);
      const heapUsed = () => { const base = Module._rv_rdram(), R = a => Module.HEAPU32[(base + (a - 0x80000000)) >>> 2] >>> 0; const hp = R(0x80052458); let blk = R(hp + 4), n = 0, used = 0; while (blk >= 0x80000000 && blk < 0x80800000 && n < 5000) { const f = R(blk + 16); if (f >>> 28) used += f & 0xFFFFFFF; n++; const nx = R(blk + 8); if (!nx || nx === blk) break; blk = nx; } return n + ' blocks ' + (used >> 10) + ' KB'; };
      if (t - lastStat >= 2) { lastStat = t; if (process.env.HEAP) console.log('heap ' + heapUsed()); console.log('t=' + t.toFixed(0) + ' vis=' + Module._rv_stat(0) + ' gfx=' + Module._rv_stat(1) + ' audio=' + Module._rv_stat(2) + ' pakR=' + Module._rv_stat(6) + ' pakW=' + Module._rv_stat(7) + ' hung=' + Module._rv_stat(8)); }
      Module._rv_frame(); frames++;
      if (Date.now() - t0 < secs * 1000) return setTimeout(tick, 16);
      console.log(JSON.stringify({ frames, vis: Module._rv_stat(0), gfx: Module._rv_stat(1), audioTasks: Module._rv_stat(2), audioFrames: Module.rvAudioFrames || 0, rate: Module.rvAudioRate, msGame: Math.round(Module._rv_stat(3)) }));
      if (process.env.SAVEOUT) { const p = Module._rv_save_ptr(), n = Module._rv_save_size(); fs.writeFileSync(process.env.SAVEOUT, Buffer.from(Module.HEAPU8.slice(p, p + n))); console.log('save dirty=' + Module._rv_save_dirty() + ' bytes=' + n); }
      process.exit(0);
    };
    setTimeout(tick, 16);
  },
  onAbort: w => { console.error('ABORT', w); process.exit(2); },
};
global.require = require; global.__dirname = '/home/claude/bzweb/build'; global.__filename = '/home/claude/bzweb/build/blitz.js';
require('vm').runInThisContext(fs.readFileSync('/home/claude/bzweb/build/blitz.js', 'utf8'), { filename: 'blitz.js' });
