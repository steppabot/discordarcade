"""List functions in syms/dump.toml that contain instructions N64Recomp can't translate
(cop0, cache, eret, tlb*, cop2 loads/stores), skipping ones with library names
(those are provided or ignored by the runtime)."""
import re, struct, rabbitizer, sys
rom = open('blitz.z64', 'rb').read()
lists = open('/home/claude/rvtools/N64RecompSource/src/symbol_lists.cpp').read()
lib = set(re.findall(r'"([^"]+)"', lists))
sec = None; out = []
for line in open('syms/dump.toml'):
    m = re.match(r'rom = (0x[0-9A-F]+)', line)
    if m: srom = int(m.group(1), 16)
    m = re.match(r'vram = (0x[0-9A-F]+)', line)
    if m and 'name' not in line: svram = int(m.group(1), 16)
    m = re.search(r'name = "(\S+)", vram = (0x[0-9A-F]+), size = (0x[0-9A-F]+)', line)
    if not m: continue
    name, v, size = m.group(1), int(m.group(2), 16), int(m.group(3), 16)
    if name in lib: continue
    bad = []
    for a in range(v, v + size, 4):
        o = srom + (a - svram); w = struct.unpack('>I', rom[o:o + 4])[0]
        op = w >> 26; ins = rabbitizer.Instruction(w, vram=a)
        mn = ins.getOpcodeName()
        if op == 0x10 or mn in ('cache', 'eret') or mn.startswith('tlb') or op in (0x32, 0x3A, 0x12):
            bad.append('%08X:%s' % (a, ins.disassemble().split()[0]))
    if bad: out.append((name, bad))
for name, bad in out: print(name, len(bad), ' '.join(bad[:4]))
print('#', len(out), 'functions with untranslatable instructions', file=sys.stderr)
