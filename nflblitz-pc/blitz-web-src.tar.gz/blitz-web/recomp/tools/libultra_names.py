"""Match n64sym's library identifications against splat's function starts and
N64Recomp's built-in name lists. Prints which names would be renamed and flags
duplicates or names that don't sit on a function start."""
import re, collections, glob, sys
lists = open('/home/claude/rvtools/N64RecompSource/src/symbol_lists.cpp').read()
def block(name):
    i = lists.index('N64Recomp::' + name); j = lists.index('};', i)
    return set(re.findall(r'"([^"]+)"', lists[i:j]))
reimpl, ignored, renamed = block('reimplemented_funcs'), block('ignored_funcs'), block('renamed_funcs')
funcs = {}
for f in glob.glob('/home/claude/blitz/proj/disasm/asm/*.s'):
    for line in open(f):
        m = re.match(r'^nonmatching (func_([0-9A-F]{8})\S*), (0x[0-9A-Fa-f]+)', line)
        if m: funcs[int(m.group(2), 16)] = (m.group(1), int(m.group(3), 16))
syms = collections.defaultdict(list)
for line in open('/home/claude/blitz/n64sym-main.txt'):
    m = re.match(r'(\S+) = (0x[0-9A-F]+);', line)
    if m: syms[m.group(1)].append(int(m.group(2), 16))
out = {}
for name, addrs in sorted(syms.items(), key=lambda kv: kv[1][0]):
    kind = 'reimpl' if name in reimpl else 'ignored' if name in ignored else 'renamed' if name in renamed else None
    if not kind: continue
    for a in addrs:
        at = funcs.get(a)
        flag = '' if at else '  NOT A FUNCTION START'
        if len(addrs) > 1: flag += '  DUPLICATE x%d' % len(addrs)
        print('%-8s %-28s %08X %s%s' % (kind, name, a, at[0] if at else '-', flag))
        if at and len(addrs) == 1: out[at[0]] = name
print('#', len(out), 'clean renames;', 'reimpl', len(reimpl), 'ignored', len(ignored), 'renamed', len(renamed), file=sys.stderr)
import json; json.dump(out, open('/home/claude/blitz/proj/syms/n64sym_renames.json', 'w'), indent=1)
