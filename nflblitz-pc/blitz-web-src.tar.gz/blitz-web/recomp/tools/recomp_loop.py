#!/usr/bin/env python3
"""Run N64Recomp until it succeeds, fixing functions splat cut at the wrong place.

For the function N64Recomp fails on ("Unhandled branch in F at A to T"):
  forward target (past F's end): F really continues there -> extend F's size to the
    end of the function containing T (that function stays as its own entry too;
    N64Recomp recompiles each function independently, so overlap is fine).
  backward target (before F's start): F is the tail of an earlier function C ->
    extend C over F; drop F as a symbol unless something jal's it (then stop for review).
Other failures stop the loop and print N64Recomp's output."""
import json, re, subprocess, glob, sys
ROOT = '/home/claude/blitz/proj'
SIZES = ROOT + '/syms/size_overrides.json'
SKIPF = ROOT + '/syms/skip_functions.txt'
EXTRAF = ROOT + '/syms/extra_functions.json'

def funcs():
    out, sec = {}, None
    for line in open(ROOT + '/syms/dump.toml'):
        m = re.match(r'name = "(\S+)"', line)
        if m: sec = m.group(1)
        m = re.search(r'name = "(\S+)", vram = (0x[0-9A-F]+), size = (0x[0-9A-F]+)', line)
        if m: out[m.group(1)] = (sec, int(m.group(2), 16), int(m.group(3), 16))
    return out

def containing(fs, sec, addr, exclude):
    best = None
    for n, (s, v, z) in fs.items():
        if s == sec and n != exclude and v <= addr < v + z and (best is None or v > fs[best][1]): best = n
    return best

asm = '\n'.join(open(f).read() for f in glob.glob(ROOT + '/disasm/asm/*.s'))
def callers(name):
    """VRAM of every jal to name (from the instruction comments)."""
    return [int(m.group(1), 16) for m in re.finditer(r'/\* [0-9A-F]+ ([0-9A-F]{8}) [0-9A-F]{8} \*/\s+jal\s+' + re.escape(name) + r'_?\b', asm)]

sizes = json.load(open(SIZES)) if __import__('os').path.exists(SIZES) else {}
skip = set(l.strip() for l in open(SKIPF)) if __import__('os').path.exists(SKIPF) else set()
for it in range(400):
    subprocess.run(['python3', ROOT + '/tools/gen_symbols.py'], check=True, capture_output=True)
    p = subprocess.run(['/home/claude/rvtools/N64RecompSource/build/N64Recomp', 'blitz.toml'], cwd=ROOT, capture_output=True, text=True)
    log = p.stdout + p.stderr
    if p.returncode == 0:
        print('N64Recomp succeeded after', it, 'fixes'); break
    m = re.search(r'Error recompiling (\S+)', log)
    if not m: print(log[-3000:]); sys.exit(1)
    fail = m.group(1); fs = funcs(); sec, v0, sz = fs[fail]
    nj = re.findall(r'No function found for jal target: (0x[0-9A-Fa-f]+)', log)
    if nj:
        x = int(nj[0], 16); cands = [n for n, (s, v, z) in fs.items() if v <= x < v + z and (s == sec or s in ('main', 'shared'))]
        if not cands: print('jal target %X is in no function' % x); print(log[-2000:]); sys.exit(1)
        c = cands[0]; s, v, z = fs[c]
        extra = json.load(open(EXTRAF)) if __import__('os').path.exists(EXTRAF) else {}
        name = 'func_%08X' % x
        if any(e[0] == name for e in extra.get(s, [])): print('extra entry %s already added' % name); sys.exit(1)
        extra.setdefault(s, []).append([name, x, v + z - x]); json.dump(extra, open(EXTRAF, 'w'), indent=1)
        print('add entry %s inside %s (%s, size 0x%X)' % (name, c, s, v + z - x)); continue
    targets = [int(t, 16) for t in re.findall(r'Unhandled branch in ' + re.escape(fail) + r' at 0x[0-9A-Fa-f]+ to (0x[0-9A-Fa-f]+)', log)]
    if not targets: print('cannot fix', fail); print(log[-3000:]); sys.exit(1)
    fwd = [t for t in targets if t >= v0 + sz]; back = [t for t in targets if t < v0]
    if back:
        c = containing(fs, sec, min(back), fail)
        if not c: print('no function contains backward target %X of %s' % (min(back), fail)); sys.exit(1)
        sizes[c] = max(sizes.get(c, fs[c][2]), v0 + sz - fs[c][1])
        outside = [x for x in callers(fail) if not (fs[c][1] <= x < fs[c][1] + sizes[c])]
        if outside: print('REVIEW: %s is a tail of %s but is called from %s' % (fail, c, ' '.join('%X' % x for x in outside))); sys.exit(1)
        skip.add(fail); print('merge %s into %s (size 0x%X)' % (fail, c, sizes[c]))
    if fwd:
        end = v0 + sz
        for t in fwd:
            c = containing(fs, sec, t, fail)
            end = max(end, (fs[c][1] + fs[c][2]) if c else t + 4)
        sizes[fail] = end - v0; print('extend %s to 0x%X (targets %s)' % (fail, end - v0, ' '.join('%X' % t for t in fwd)))
    json.dump(sizes, open(SIZES, 'w'), indent=1, sort_keys=True)
    open(SKIPF, 'w').write('\n'.join(sorted(skip)) + '\n')
else:
    print('gave up after 400 fixes')
