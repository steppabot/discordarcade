WCW/nWo Revenge for the web: build sources
==========================================

This is the source for revenge-pc/revenge.js + revenge.wasm on the Token arcade.

It combines:
- WCWnWoRevengeRecomp (GPL-3.0), https://github.com/jessetbh/WCWnWoRevengeRecomp
  The game code is generated from your own ROM with N64Recomp (revenge.toml) and
  RSPRecomp (rsp/revenge_audio.toml), then the repo's tools/fix_jraddend.py and
  tools/readd_hand_edits.py. Its N64ModernRuntime submodule (librecomp, ultramodern)
  supplies the rest of the runtime.
- GLideN64 (GPL-2.0-or-later), https://github.com/gonetz/GLideN64 at commit
  a04081ad6a966a9413bea63a55f502e0dc98bb18, with gliden64-web.patch applied (WebGL 2
  function loading, pixel reads without mapped buffers, building a list of known
  shaders whenever the renderer starts or resizes).
- The files in src/: cooperative (single-thread) versions of ultramodern's threads,
  message queues, timers and events built on emscripten fibers (coop_*.cpp), the PI
  and save code (web_pi.cpp), the boot and per-frame loop (web_main.cpp), and the glue
  that runs GLideN64 as the renderer on a WebGL 2 canvas (web_gliden64.cpp).

Build with Emscripten 4.0.1: edit the paths at the top of build.py, then
  python3 build.py compile && python3 build.py link
No ROM or game data is included here.

Shaders: src/rv_combiner_keys.inc lists the GLideN64 combiner keys (shader ids) the game
uses, recorded by playing it with test/record.mjs. They are built at start-up and after
every resize, and new ones build in the background (KHR_parallel_shader_compile), so
camera cuts never wait for a shader to compile.
