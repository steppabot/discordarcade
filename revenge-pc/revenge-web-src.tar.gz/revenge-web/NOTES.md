# WCW/nWo Revenge in the browser — working notes

Source: jessetbh/WCWnWoRevengeRecomp (GPL-3.0), cloned at /home/claude/jessetbh/wcwnworevengerecomp
(submodule lib/N64ModernRuntime fetched; lib/rt64 and lib/RecompFrontend NOT fetched — not used on web).
ROM: /home/claude/discordarcade/games/n64/wcwvsnworevenge.z64 — SHA1 e1711a25… = the exact US ROM the
project needs. Symlinked as revenge.z64 in the repo root.

## Done (step 1)
- N64Recomp built at pinned commit ffb39cd: /home/claude/rvtools/N64RecompSource/build/{N64Recomp,RSPRecomp}
- Ran `N64Recomp revenge.toml` -> RecompiledFuncs/ (34 funcs_*.c, funcs.h, lookup.cpp, recomp_overlays.inl, 18 MB C)
  and `RSPRecomp rsp/revenge_audio.toml` -> rsp/revenge_audio.cpp. Then tools/fix_jraddend.py, tools/readd_hand_edits.py.
- All of it compiles with emcc -O2 (objects in /home/claude/rvtools/wobj). Game links to ~2.0 MB wasm
  (590 KB gz). Full ASYNCIFY with blocking imports only adds ~4% (2.06 MB).
- Game code imports only 47 runtime functions (spike: /home/claude/rvtools/spike/imports.txt):
  libultra threads/mesg queues/VI/AI/SP/PI/SI + pause_self, get_function, do_break, switch_error,
  wcw_rt_emit_camera, wcw_rt_latch_camera_multiply, wcw_widescreen_cull_scale (RT64 hooks -> no-op / 1.0).
- Graphics microcode: standard F3DEX 2.06 (+ F3DLX.Rej).

## Build tree (/home/claude/rvweb)
- build.py: `compile [filter]` / `link`. Reused runtime files compile (23/24); pi.cpp is too tied to
  threads/save-backups/mods -> write src/web_pi.cpp instead (rom vector, do_rom_read with MEM_B, osCartRomInit
  (cart_handle, phys_to_k1(rom_base)), osCreatePiManager no-op, osPiStartDma/osEPiStartDma -> do_dma: ROM read or
  SRAM (save type Sram, 0x8000 bytes) then enqueue_external_message(mq, 0, false, true)). Revenge has no overlays.
- src/ultramodern/renderer_context.hpp: web copy adding __EMSCRIPTEN__ (WindowHandle = SDL_Window*).
- src/miniz_export.h stub. mods.hpp static_asserts sizeof(long)==8 -> never include it in web files.

## Runtime semantics to replicate (from ultramodern, WCW fork)
- threads.cpp: one game thread runs at a time. run_next_thread(): pop running_queue head -> signal its ctx.
  run_next_thread_and_wait(): run_next_thread + wait own semaphore. resume_thread(t): signal t.
  _thread_func: thread_self=t; wait until resumed; run_thread_function(rdram, entry, t->sp, arg) (librecomp
  recomp.cpp: ctx.r29=sp, r4=arg, f_odd=&f0.u32h, get_function(addr)(rdram,&ctx)); on return: context=null,
  run_next_thread. osCreateThread: next/queue=0, priority, id, state=STOPPED, sp-=0x10, new context.
  osStartThread: if thread_self -> schedule_running_thread + check_running_queue; else (boot) state=QUEUED +
  resume. osDestroyThread(self) throws thread_terminated -> in coop: mark dead, never resume.
  WCW fork keeps an authoritative host map t_ -> {ctx, pri, id} and repairs game-wiped TCB fields; keep that idea.
- events.cpp: osSetEventMesg stores (mq,msg) for SP/DP/AI/SI. osViSetEvent sets mq/msg/retrace_count on BOTH
  vi states. VI tick 60 Hz: once game started: remaining_retraces-- ; at 0 enqueue VI msg (external, no requeue)
  and reset to retrace_count; ALSO enqueue the AI event msg every VI. Then vi.update_vi() + ScreenUpdateAction
  (renderer update_screen with vi regs) + vi_callback (rumble).
  SP tasks: submit_rsp_task -> task queue; audio tasks run via ultramodern::rsp::run_task (RSPRecomp) then
  sp_complete() = enqueue(sp.mq, sp.msg, requeue=true). Gfx tasks go to the gfx thread: renderer->send_dl,
  then sp_complete + dp_complete. osViSwapBuffer sets next framebuffer.
- mesgqueue.cpp: external messages queue; idle thread (pause_self) waits in wait_for_external_message;
  dequeue_external_messages delivers via do_send (non-blocking; requeue_if_blocked when queue full).

## Status (Nov 1)
- Runtime done: src/coop_*.cpp (fibers), web_pi.cpp, web_main.cpp (boot + rv_frame loop), rv_pre.js defaults.
  Headless node test: test/headless.js (null renderer path). Boots, 7 threads, 30 fps game, audio tasks per VI.
- Renderer done: GLideN64 copy in gliden64/src (patches: GLFunctions.cpp emscripten proc loading,
  opengl_ContextImpl.cpp ReadPixels reader, opengl_BufferManipulationObjectFactory.cpp getBufferSubData),
  glue src/web_gliden64.cpp (fake mupen64plus core: config store + VidExt on #canvas; GlideRenderer:
  task -> DMEM 0xFC0 with PHYSICAL addresses (mask 0x1FFFFFFF, else black screen), ProcessDList; UpdateScreen).
  Page overrides: Module.rvGlide = {Key: value}. EnableCopyColorToRDRAM=1 costs a sync ReadPixels per frame
  (SwiftShader: 18 s of 20 s) - default it OFF on web (menus + match look right without it).
- Frame loop: each due VI is delivered then the game runs until idle (+gfx) before the next VI (burst
  delivery lost retraces -> half speed).
- Browser test: test/www (python http.server 8765), test/seq.mjs (schedule pad presses, screenshots),
  test/sheet.py contact sheet. Intro, title, menus, wrestler select, full match verified in SwiftShader.

- Page: /home/claude/discordarcade/revenge-pc/ (index.html, revenge.js/.wasm, rv-audio.js worklet,
  revenge-web-src.tar.gz for GPL). Keyboard/gamepad/touch in JS -> _rv_set_pad(idx, bits, x, y) (stick -80..80).
  Saves: SRAM via _rv_save_* <-> localStorage 'token-revenge-sram'. Group host API window.geGroup (same as GE).
- Arcade: arcade-player.html PC_PORTS routes /games/n64/wcwvsnworevenge.z64 -> revenge-pc/; arcade-group.js
  pcEngine(container, "revenge"), hello {e:"rv"}, guest rvInput + createPad layout "rv" (stick -> d-pad).
  Tests: scratchpad/mpdev/mp_rv_e2e.mjs (3 players), scratchpad/ff/ffrv.mjs (Firefox).
- Asyncify: full instrumentation (IGNORE_INDIRECT + ADD func_* crashed: some indirect yield path missed).

## Plan
- Runtime (approach A): reuse portable librecomp (overlays, pi, si/cont, eep/sram, vi, ai, sp, rsp,
  ultra_translation) + ultramodern scheduling.cpp/threadqueue.cpp/mesgqueue.cpp logic; REWRITE threads.cpp,
  events.cpp, timer.cpp (and external-message waits) as cooperative emscripten fibers driven by a rAF loop —
  same model as GoldenEye's portCoopFrame (port/src/libultra.c in the GE port). Align fiber C stacks to 16
  (aligned_alloc) — see GE Firefox swirl bug.
  * run_next_thread_and_wait -> swap to next runnable fiber; wait_for_resumed -> swap out.
  * idle thread pause_self / wait_for_external_message -> swap to main fiber (browser) when queue empty.
  * rAF loop: post VI (60 Hz, catch-up <= 4/pass, reset after 8), service timers, run SP tasks inline
    (audio via revenge_audio RSPRecomp; gfx -> renderer), run fibers until idle.
  * Mods/LiveRecomp (runtime JIT) disabled. Saves: SRAM to MEMFS + localStorage like GE.
- Renderer: GLideN64 (GLES3 -> WebGL2, as in the arcade's EmulatorJS mupen64plus_next core) behind
  ultramodern::renderer::RendererContext (send_dl -> ProcessDList, update_screen -> UpdateScreen).
  RDRAM layout already matches mupen64plus (native 32-bit words, byte addr ^3).
- Audio: queue_samples -> AudioWorklet glue (copy GE's geAudio* page functions + ge-audio.js).
- Page: revenge-pc/ like goldeneye-pc (ROM from /games/n64/wcwvsnworevenge.z64, touch pad, fullscreen,
  saves), N64 card routing in arcade-player.html, group engine (view "shared").
