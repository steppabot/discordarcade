// GLideN64 as the web renderer. GLideN64 is built as a mupen64plus video plugin; this
// file stands in for the mupen64plus core it talks to (config API, video extension on a
// WebGL2 canvas) and adapts it to ultramodern's RendererContext: a gfx task is copied
// into a fake DMEM and run with ProcessDList, a screen update runs UpdateScreen with the
// VI registers ultramodern keeps.
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <map>
#include <memory>
#include <string>
#include <emscripten.h>
#include <emscripten/html5.h>

#define M64P_PLUGIN_PROTOTYPES 1
#include "m64p_types.h"
#include "m64p_plugin.h"
#include "m64p_config.h"
#include "m64p_vidext.h"

#include "ultramodern/ultra64.h"
#include "ultramodern/renderer_context.hpp"
#include "librecomp/game.hpp"

extern "C" {
m64p_error PluginStartup(m64p_dynlib_handle CoreLibHandle, void* Context, void (*DebugCallback)(void*, int, const char*));
}

// ---- Config store (mupen64plus config API) ---------------------------------------------
namespace {
struct Param {
    m64p_type type = M64TYPE_INT;
    int i = 0;
    float f = 0;
    std::string s;
};
using Section = std::map<std::string, Param>;
std::map<std::string, Section> sections;

// Web defaults that differ from GLideN64's. Applied when GLideN64 registers the default.
const std::map<std::string, std::string> web_settings = {
    { "Video-General/ScreenWidth", "640" },
    { "Video-General/ScreenHeight", "480" },
    { "Video-General/VerticalSync", "0" },
    { "Video-GLideN64/ThreadedVideo", "0" },
    { "Video-GLideN64/AsyncShaderCompilation", "0" },
    { "Video-GLideN64/MultiSampling", "0" },
    { "Video-GLideN64/AspectRatio", "1" },          // 4:3
    { "Video-GLideN64/UseNativeResolutionFactor", "0" },
    { "Video-GLideN64/EnableShadersStorage", "0" },
    { "Video-GLideN64/EnableCustomSettings", "0" },
    { "Video-GLideN64/txHiresEnable", "0" },
    { "Video-GLideN64/txSaveCache", "0" },
    { "Video-GLideN64/ShowFPS", "0" },
    { "Video-GLideN64/EnableFBEmulation", "1" },
    // A synchronous ReadPixels per frame on WebGL; the game renders correctly without it.
    { "Video-GLideN64/EnableCopyColorToRDRAM", "0" },
};

void apply_web_setting(const char* section, const char* name, Param& p) {
    std::string key = std::string(section) + "/" + name;
    std::string v;
    // The page may override any setting: Module.rvGlide = { "EnableCopyColorToRDRAM": "0", ... }.
    char* page = (char*)EM_ASM_PTR({
        var g = Module.rvGlide || {};
        var v = g[UTF8ToString($0)];
        return v === undefined ? 0 : stringToNewUTF8(String(v));
    }, name);
    if (page) {
        v = page;
        free(page);
    } else {
        auto it = web_settings.find(key);
        if (it == web_settings.end()) return;
        v = it->second;
    }
    switch (p.type) {
        case M64TYPE_INT: case M64TYPE_BOOL: p.i = std::stoi(v); break;
        case M64TYPE_FLOAT: p.f = std::stof(v); break;
        case M64TYPE_STRING: p.s = v; break;
    }
}

std::string section_name(m64p_handle h) {
    for (auto& [name, sec] : sections) {
        if (&sec == h) return name;
    }
    return "";
}

m64p_error cfg_open_section(const char* name, m64p_handle* h) {
    *h = &sections[name];
    return M64ERR_SUCCESS;
}
m64p_error cfg_delete_section(const char* name) { sections.erase(name); return M64ERR_SUCCESS; }
m64p_error cfg_save_section(const char*) { return M64ERR_SUCCESS; }
m64p_error cfg_save_file() { return M64ERR_SUCCESS; }

template <typename F>
m64p_error set_default(m64p_handle h, const char* name, m64p_type type, F fill) {
    Section& sec = *(Section*)h;
    if (sec.count(name)) return M64ERR_SUCCESS;
    Param p;
    p.type = type;
    fill(p);
    apply_web_setting(section_name(h).c_str(), name, p);
    sec[name] = p;
    return M64ERR_SUCCESS;
}
m64p_error cfg_default_int(m64p_handle h, const char* n, int v, const char*) { return set_default(h, n, M64TYPE_INT, [&](Param& p) { p.i = v; }); }
m64p_error cfg_default_float(m64p_handle h, const char* n, float v, const char*) { return set_default(h, n, M64TYPE_FLOAT, [&](Param& p) { p.f = v; }); }
m64p_error cfg_default_bool(m64p_handle h, const char* n, int v, const char*) { return set_default(h, n, M64TYPE_BOOL, [&](Param& p) { p.i = v ? 1 : 0; }); }
m64p_error cfg_default_string(m64p_handle h, const char* n, const char* v, const char*) { return set_default(h, n, M64TYPE_STRING, [&](Param& p) { p.s = v ? v : ""; }); }

const Param* find_param(m64p_handle h, const char* n) {
    Section& sec = *(Section*)h;
    auto it = sec.find(n);
    return it == sec.end() ? nullptr : &it->second;
}
int cfg_get_int(m64p_handle h, const char* n) { auto p = find_param(h, n); return p ? (p->type == M64TYPE_FLOAT ? (int)p->f : p->i) : 0; }
float cfg_get_float(m64p_handle h, const char* n) { auto p = find_param(h, n); return p ? (p->type == M64TYPE_FLOAT ? p->f : (float)p->i) : 0.0f; }
int cfg_get_bool(m64p_handle h, const char* n) { return cfg_get_int(h, n) != 0; }
const char* cfg_get_string(m64p_handle h, const char* n) { auto p = find_param(h, n); return p ? p->s.c_str() : ""; }

const char* cfg_shared_data_filepath(const char*) { return nullptr; }
const char* cfg_user_config_path() { return "/gliden64"; }
const char* cfg_user_data_path() { return "/gliden64"; }
const char* cfg_user_cache_path() { return "/gliden64"; }
m64p_error cfg_external_open(const char*, m64p_handle*) { return M64ERR_FILES; }
m64p_error cfg_external_close(m64p_handle) { return M64ERR_SUCCESS; }
m64p_error cfg_external_get(m64p_handle, const char*, const char*, char*, int) { return M64ERR_INPUT_NOT_FOUND; }

// ---- Video extension on a WebGL2 canvas ------------------------------------------------
EMSCRIPTEN_WEBGL_CONTEXT_HANDLE gl_context = 0;
int canvas_w = 640, canvas_h = 480;

m64p_error vid_init() { return M64ERR_SUCCESS; }
m64p_error vid_quit() { return M64ERR_SUCCESS; }
m64p_error vid_list_modes(m64p_2d_size*, int* n) { if (n) *n = 0; return M64ERR_SUCCESS; }
m64p_error vid_list_rates(m64p_2d_size, int* n, int*) { if (n) *n = 0; return M64ERR_SUCCESS; }

m64p_error vid_set_mode(int w, int h, int, m64p_video_mode, m64p_video_flags) {
    canvas_w = w;
    canvas_h = h;
    emscripten_set_canvas_element_size("#canvas", w, h);
    if (gl_context == 0) {
        EmscriptenWebGLContextAttributes attrs;
        emscripten_webgl_init_context_attributes(&attrs);
        attrs.majorVersion = 2;
        attrs.minorVersion = 0;
        attrs.alpha = false;
        attrs.depth = true;
        attrs.stencil = false;
        attrs.antialias = false;
        attrs.premultipliedAlpha = false;
        attrs.preserveDrawingBuffer = false;
        attrs.powerPreference = EM_WEBGL_POWER_PREFERENCE_HIGH_PERFORMANCE;
        attrs.enableExtensionsByDefault = true;
        gl_context = emscripten_webgl_create_context("#canvas", &attrs);
        if (gl_context <= 0) {
            fprintf(stderr, "[web][gl] WebGL2 context creation failed (%d)\n", (int)gl_context);
            gl_context = 0;
            return M64ERR_SYSTEM_FAIL;
        }
    }
    emscripten_webgl_make_context_current(gl_context);
    return M64ERR_SUCCESS;
}
m64p_error vid_set_mode_rate(int w, int h, int, int bpp, m64p_video_mode m, m64p_video_flags f) { return vid_set_mode(w, h, bpp, m, f); }
m64p_error vid_set_caption(const char*) { return M64ERR_SUCCESS; }
m64p_error vid_toggle_fs() { return M64ERR_SUCCESS; }
m64p_error vid_resize(int w, int h) { canvas_w = w; canvas_h = h; emscripten_set_canvas_element_size("#canvas", w, h); return M64ERR_SUCCESS; }
m64p_function vid_get_proc(const char* name) { return (m64p_function)emscripten_webgl_get_proc_address(name); }
m64p_error vid_set_attr(m64p_GLattr, int) { return M64ERR_SUCCESS; }
m64p_error vid_get_attr(m64p_GLattr, int* v) { if (v) *v = 0; return M64ERR_SUCCESS; }
// The browser presents the canvas when the frame's JS returns.
m64p_error vid_swap() { return M64ERR_SUCCESS; }
uint32_t vid_default_fb() { return 0; }

m64p_error core_get_version(m64p_plugin_type* type, int* version, int* api, const char** name, int* caps) {
    if (type) *type = M64PLUGIN_CORE;
    if (version) *version = 0x020600;
    if (api) *api = 0x020001;
    if (name) *name = "web";
    if (caps) *caps = 0;
    return M64ERR_SUCCESS;
}

const std::map<std::string, void*> core_symbols = {
    { "ConfigGetSharedDataFilepath", (void*)cfg_shared_data_filepath },
    { "ConfigGetUserConfigPath", (void*)cfg_user_config_path },
    { "ConfigGetUserCachePath", (void*)cfg_user_cache_path },
    { "ConfigGetUserDataPath", (void*)cfg_user_data_path },
    { "ConfigOpenSection", (void*)cfg_open_section },
    { "ConfigDeleteSection", (void*)cfg_delete_section },
    { "ConfigSaveSection", (void*)cfg_save_section },
    { "ConfigSaveFile", (void*)cfg_save_file },
    { "ConfigSetDefaultInt", (void*)cfg_default_int },
    { "ConfigSetDefaultFloat", (void*)cfg_default_float },
    { "ConfigSetDefaultBool", (void*)cfg_default_bool },
    { "ConfigSetDefaultString", (void*)cfg_default_string },
    { "ConfigGetParamInt", (void*)cfg_get_int },
    { "ConfigGetParamFloat", (void*)cfg_get_float },
    { "ConfigGetParamBool", (void*)cfg_get_bool },
    { "ConfigGetParamString", (void*)cfg_get_string },
    { "ConfigExternalGetParameter", (void*)cfg_external_get },
    { "ConfigExternalOpen", (void*)cfg_external_open },
    { "ConfigExternalClose", (void*)cfg_external_close },
    { "VidExt_Init", (void*)vid_init },
    { "VidExt_Quit", (void*)vid_quit },
    { "VidExt_ListFullscreenModes", (void*)vid_list_modes },
    { "VidExt_ListFullscreenRates", (void*)vid_list_rates },
    { "VidExt_SetVideoMode", (void*)vid_set_mode },
    { "VidExt_SetVideoModeWithRate", (void*)vid_set_mode_rate },
    { "VidExt_SetCaption", (void*)vid_set_caption },
    { "VidExt_ToggleFullScreen", (void*)vid_toggle_fs },
    { "VidExt_ResizeWindow", (void*)vid_resize },
    { "VidExt_GL_GetProcAddress", (void*)vid_get_proc },
    { "VidExt_GL_SetAttribute", (void*)vid_set_attr },
    { "VidExt_GL_GetAttribute", (void*)vid_get_attr },
    { "VidExt_GL_SwapBuffers", (void*)vid_swap },
    { "VidExt_GL_GetDefaultFramebuffer", (void*)vid_default_fb },
    { "PluginGetVersion", (void*)core_get_version },
};

void debug_callback(void*, int level, const char* msg) {
    if (level <= M64MSG_WARNING) {
        fprintf(stderr, "[gliden64] %s\n", msg);
    }
}
} // namespace

// GLideN64's mupenplus glue resolves core functions with dlsym (renamed to this at build).
extern "C" void* rv_dlsym(void* handle, const char* name) {
    auto it = core_symbols.find(name);
    return it == core_symbols.end() ? nullptr : it->second;
}

// ---- RendererContext ---------------------------------------------------------------------
namespace {
void check_interrupts() {}

class GlideRenderer : public ultramodern::renderer::RendererContext {
public:
    GlideRenderer(uint8_t* rdram) {
        PluginStartup((m64p_dynlib_handle)1, nullptr, debug_callback);

        // ROM header in the core's word-swapped layout (byte i at i ^ 3).
        auto rom = recomp::get_rom();
        for (uint32_t i = 0; i < sizeof(header) && i < rom.size(); i++) {
            header[i ^ 3] = rom[i];
        }
        ultramodern::renderer::ViRegs* vi = ultramodern::renderer::get_vi_regs();
        GFX_INFO gi{};
        gi.HEADER = header;
        gi.RDRAM = rdram;
        gi.DMEM = dmem;
        gi.IMEM = imem;
        gi.MI_INTR_REG = &mi_intr;
        gi.DPC_START_REG = &dpc[0];
        gi.DPC_END_REG = &dpc[1];
        gi.DPC_CURRENT_REG = &dpc[2];
        gi.DPC_STATUS_REG = &dpc[3];
        gi.DPC_CLOCK_REG = &dpc[4];
        gi.DPC_BUFBUSY_REG = &dpc[5];
        gi.DPC_PIPEBUSY_REG = &dpc[6];
        gi.DPC_TMEM_REG = &dpc[7];
        gi.VI_STATUS_REG = &vi->VI_STATUS_REG;
        gi.VI_ORIGIN_REG = &vi->VI_ORIGIN_REG;
        gi.VI_WIDTH_REG = &vi->VI_WIDTH_REG;
        gi.VI_INTR_REG = &vi->VI_INTR_REG;
        gi.VI_V_CURRENT_LINE_REG = &vi->VI_V_CURRENT_LINE_REG;
        gi.VI_TIMING_REG = &vi->VI_TIMING_REG;
        gi.VI_V_SYNC_REG = &vi->VI_V_SYNC_REG;
        gi.VI_H_SYNC_REG = &vi->VI_H_SYNC_REG;
        gi.VI_LEAP_REG = &vi->VI_LEAP_REG;
        gi.VI_H_START_REG = &vi->VI_H_START_REG;
        gi.VI_V_START_REG = &vi->VI_V_START_REG;
        gi.VI_V_BURST_REG = &vi->VI_V_BURST_REG;
        gi.VI_X_SCALE_REG = &vi->VI_X_SCALE_REG;
        gi.VI_Y_SCALE_REG = &vi->VI_Y_SCALE_REG;
        gi.CheckInterrupts = check_interrupts;
        gi.version = 2;
        gi.SP_STATUS_REG = &sp_status;
        gi.RDRAM_SIZE = &rdram_size;
        InitiateGFX(gi);
        ok = RomOpen() != 0 && gl_context != 0;
        fprintf(stderr, "[web][gl] renderer start ok=%d ctx=%d\n", (int)ok, (int)gl_context);
        if (!ok) {
            fprintf(stderr, "[web][gl] GLideN64 failed to start\n");
        }
    }

    bool valid() override { return ok; }
    bool update_config(const ultramodern::renderer::GraphicsConfig&, const ultramodern::renderer::GraphicsConfig&) override { return true; }
    void enable_instant_present() override {}

    void send_dl(const OSTask* task) override {
        // OSTask lives at DMEM 0xFC0 (native 32-bit words, as the core keeps DMEM).
        // As osSpTaskLoad does on hardware, the RSP sees physical addresses.
        OSTask t = *task;
        auto phys = [](auto& v) { if (v) v = (std::remove_reference_t<decltype(v)>)((uint32_t)v & 0x1FFFFFFF); };
        phys(t.t.ucode_boot); phys(t.t.ucode); phys(t.t.ucode_data); phys(t.t.dram_stack);
        phys(t.t.output_buff); phys(t.t.output_buff_size); phys(t.t.data_ptr); phys(t.t.yield_data_ptr);
        memcpy(dmem + 0xFC0, &t, sizeof(OSTask));
        ProcessDList();
    }

    void send_dummy_workload(uint32_t) override {}

    void update_screen() override {
        ultramodern::renderer::ViRegs* vi = ultramodern::renderer::get_vi_regs();
        if (vi->VI_STATUS_REG != last_status) {
            last_status = vi->VI_STATUS_REG;
            ViStatusChanged();
        }
        if (vi->VI_WIDTH_REG != last_width) {
            last_width = vi->VI_WIDTH_REG;
            ViWidthChanged();
        }
        UpdateScreen();
    }

    void shutdown() override { RomClosed(); }
    uint32_t get_display_framerate() const override { return 60; }
    float get_resolution_scale() const override { return 1.0f; }

private:
    bool ok = false;
    alignas(16) uint8_t dmem[0x1000]{};
    alignas(16) uint8_t imem[0x1000]{};
    alignas(16) uint8_t header[0x40]{};
    unsigned int mi_intr = 0, sp_status = 0;
    unsigned int dpc[8]{};
    unsigned int rdram_size = 8u << 20;
    unsigned int last_status = 0xFFFFFFFF, last_width = 0xFFFFFFFF;
};
} // namespace

// Accepts display lists and draws nothing: headless tests (Module.rvNoGL).
class NullRenderer : public ultramodern::renderer::RendererContext {
public:
    bool valid() override { return true; }
    bool update_config(const ultramodern::renderer::GraphicsConfig&, const ultramodern::renderer::GraphicsConfig&) override { return true; }
    void enable_instant_present() override {}
    void send_dl(const OSTask*) override {}
    void send_dummy_workload(uint32_t) override {}
    void update_screen() override {}
    void shutdown() override {}
    uint32_t get_display_framerate() const override { return 60; }
    float get_resolution_scale() const override { return 1.0f; }
};

std::unique_ptr<ultramodern::renderer::RendererContext> web_create_renderer(uint8_t* rdram, ultramodern::renderer::WindowHandle, bool) {
    if (EM_ASM_INT({ return Module.rvNoGL ? 1 : 0; })) {
        return std::make_unique<NullRenderer>();
    }
    return std::make_unique<GlideRenderer>(rdram);
}

// The page sets the drawing size (CSS size x devicePixelRatio, capped).
// Resizing rebuilds GLideN64's buffers, so the page only calls this when the size settles.
extern "C" EMSCRIPTEN_KEEPALIVE void rv_set_output_size(int w, int h) {
    if (w < 64 || h < 48 || (w == canvas_w && h == canvas_h)) return;
    canvas_w = w;
    canvas_h = h;
    emscripten_set_canvas_element_size("#canvas", w, h);
    ResizeVideoOutput(w, h);
}

// GLideN64's hotkeys (osal_keys) are not used on the web.
#include "osal_keys.h"
extern "C" {
void osal_keys_init() {}
void osal_keys_quit() {}
void osal_keys_update_state() {}
unsigned int osal_is_key_pressed(unsigned int, unsigned int) { return 0; }
}

// Referenced by GLideN64's threaded GL wrapper, which the web build never turns on.
#include <semaphore.h>
#include <errno.h>
extern "C" int sem_timedwait(sem_t*, const struct timespec*) {
    errno = ETIMEDOUT;
    return -1;
}
