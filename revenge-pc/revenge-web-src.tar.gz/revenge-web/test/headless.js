// Boot the web build in node with the null renderer and report progress.
const fs = require('fs');
const path = require('path');
const secs = +(process.argv[2] || 10);
const rom = fs.readFileSync('/home/claude/discordarcade/games/n64/wcwvsnworevenge.z64');
let lines = 0;
global.Module = {
  print: t => { if (lines++ < 400) console.log(t); },
  printErr: t => { if (lines++ < 400) console.error(t); },
  preRun: [() => { console.log('prerun', typeof FS, typeof Module.FS); const F = Module.FS || FS; F.mkdir('/rom'); F.writeFile('/rom/revenge.z64', rom); console.log('wrote', F.stat('/rom/revenge.z64').size); }],
  rvNoGL: true,
  rvStarted: () => {
    const t0 = Date.now();
    let frames = 0;
    const tick = () => {
      Module._rv_frame(); frames++;
      if (Date.now() - t0 < secs * 1000) return setTimeout(tick, 16);
      console.log(JSON.stringify({ frames, vis: Module._rv_stat(0), gfx: Module._rv_stat(1), audioTasks: Module._rv_stat(2), audioFrames: Module.rvAudioFrames || 0, rate: Module.rvAudioRate }));
      process.exit(0);
    };
    setTimeout(tick, 16);
  },
  onAbort: w => { console.error('ABORT', w); process.exit(2); },
};
global.require = require; global.__dirname = '/home/claude/rvweb/build'; global.__filename = '/home/claude/rvweb/build/revenge.js';
require('vm').runInThisContext(fs.readFileSync('/home/claude/rvweb/build/revenge.js', 'utf8'), { filename: 'revenge.js' });
