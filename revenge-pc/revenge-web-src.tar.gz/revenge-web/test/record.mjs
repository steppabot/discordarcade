// Play WCW/nWo Revenge on the real page with a button script, take screenshots, and save
// the GLideN64 combiner keys (shader ids) it built, merged into keys.txt.
// usage: node record.mjs <secs> "<t:bits[:x:y];...>" <shot-every> <tag>
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const fs = require('fs');
const [,, secs = '60', script = '', every = '2', tag = 'run'] = process.argv;
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required'] });
const page = await browser.newPage({ viewport: { width: 640, height: 560 } });
const logs = [];
page.on('console', m => { if (/\[web\]\[gl\]|error/i.test(m.text()) && logs.length < 50) logs.push(m.text()); });
page.on('pageerror', e => logs.push('PAGEERROR ' + e.message));
await page.goto((process.env.BASE || 'http://127.0.0.1:8797') + '/revenge-pc/' + (process.env.Q || ''));
await page.waitForSelector('#start:not([disabled])', { timeout: 60000 });
await page.click('#start');
await page.waitForFunction(() => { try { return Module._rv_stat(0) > 0; } catch { return false; } }, null, { timeout: 120000 });
const steps = script.split(';').filter(Boolean).map(s => s.split(':').map(Number));
const t0 = Date.now(); let shot = 0, nextShot = 0;
fs.mkdirSync(`/home/claude/rvweb/prof/${tag}`, { recursive: true });
while ((Date.now() - t0) / 1000 < +secs) {
  const t = (Date.now() - t0) / 1000;
  while (steps.length && steps[0][0] <= t) { const [, b, x = 0, y = 0] = steps.shift(); await page.evaluate(([b, x, y]) => Module._rv_set_pad(0, b, x, y), [b, x, y]); }
  if (+every && t >= nextShot) { await page.screenshot({ path: `/home/claude/rvweb/prof/${tag}/s-${String(shot++).padStart(3, '0')}.png`, clip: { x: 0, y: 0, width: 640, height: 560 } }); nextShot += +every; }
  await page.waitForTimeout(100);
}
const keys = await page.evaluate(() => {
  if (!Module._rv_glide_keys) return null;
  const p = Module._malloc(8 * 4096), n = Module._rv_glide_keys(p, 4096), out = [];
  const u = new Uint32Array(Module.HEAPU8.buffer, p, 2 * Math.min(n, 4096));
  for (let i = 0; i < Math.min(n, 4096); i++) out.push('0x' + u[2 * i + 1].toString(16).padStart(8, '0') + u[2 * i].toString(16).padStart(8, '0'));
  Module._free(p); return out;
});
const file = '/home/claude/rvweb/prof/keys.txt';
const all = new Set(fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split('\n').filter(Boolean) : []);
const before = all.size; for (const k of keys || []) all.add(k);
fs.writeFileSync(file, [...all].sort().join('\n') + '\n');
console.log(logs.join('\n'));
console.log(`keys this run ${keys ? keys.length : 'n/a'}, new ${all.size - before}, total ${all.size}, shots ${shot}`);
await browser.close();
